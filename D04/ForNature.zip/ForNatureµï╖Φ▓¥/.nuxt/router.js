import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _101ac2d3 = () => interopDefault(import('../pages/admin/index.vue' /* webpackChunkName: "pages/admin/index" */))
const _055f3261 = () => interopDefault(import('../pages/contact.vue' /* webpackChunkName: "pages/contact" */))
const _1a130624 = () => interopDefault(import('../pages/home.vue' /* webpackChunkName: "pages/home" */))
const _606cb9a0 = () => interopDefault(import('../pages/introduce.vue' /* webpackChunkName: "pages/introduce" */))
const _642dcbe6 = () => interopDefault(import('../pages/admin/addAuthor.vue' /* webpackChunkName: "pages/admin/addAuthor" */))
const _67281063 = () => interopDefault(import('../pages/admin/addStory.vue' /* webpackChunkName: "pages/admin/addStory" */))
const _07169892 = () => interopDefault(import('../pages/admin/gis.vue' /* webpackChunkName: "pages/admin/gis" */))
const _4c7b342c = () => interopDefault(import('../pages/admin/login.vue' /* webpackChunkName: "pages/admin/login" */))
const _5e008234 = () => interopDefault(import('../pages/admin/manage.vue' /* webpackChunkName: "pages/admin/manage" */))
const _b3a06d14 = () => interopDefault(import('../pages/admin/story.vue' /* webpackChunkName: "pages/admin/story" */))
const _99dada28 = () => interopDefault(import('../pages/admin/editStory/_title.vue' /* webpackChunkName: "pages/admin/editStory/_title" */))
const _d0557f42 = () => interopDefault(import('../pages/authors/_authorId.vue' /* webpackChunkName: "pages/authors/_authorId" */))
const _3a11f8a8 = () => interopDefault(import('../pages/gis/_authorId.vue' /* webpackChunkName: "pages/gis/_authorId" */))
const _7fd3375a = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/admin",
    component: _101ac2d3,
    name: "admin"
  }, {
    path: "/contact",
    component: _055f3261,
    name: "contact"
  }, {
    path: "/home",
    component: _1a130624,
    name: "home"
  }, {
    path: "/introduce",
    component: _606cb9a0,
    name: "introduce"
  }, {
    path: "/admin/addAuthor",
    component: _642dcbe6,
    name: "admin-addAuthor"
  }, {
    path: "/admin/addStory",
    component: _67281063,
    name: "admin-addStory"
  }, {
    path: "/admin/gis",
    component: _07169892,
    name: "admin-gis"
  }, {
    path: "/admin/login",
    component: _4c7b342c,
    name: "admin-login"
  }, {
    path: "/admin/manage",
    component: _5e008234,
    name: "admin-manage"
  }, {
    path: "/admin/story",
    component: _b3a06d14,
    name: "admin-story"
  }, {
    path: "/admin/editStory/:title?",
    component: _99dada28,
    name: "admin-editStory-title"
  }, {
    path: "/authors/:authorId?",
    component: _d0557f42,
    name: "authors-authorId"
  }, {
    path: "/gis/:authorId?",
    component: _3a11f8a8,
    name: "gis-authorId"
  }, {
    path: "/",
    component: _7fd3375a,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
