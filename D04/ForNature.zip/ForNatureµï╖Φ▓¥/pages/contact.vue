<template lang="pug">
    .contact
      p 聯絡我們
</template>

<script>
    export default {
        name: "Contact"
    }
</script>

<style scoped lnag="sass">

</style>
