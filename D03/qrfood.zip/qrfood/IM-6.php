<!DOCTYPE HTML>
<html>
	<head>
		<?php include("head.html");	?>
	</head>
	<body class="homepage">

	<!-- Header -->
		<div id="header">
			<div class="container">
					
				<!-- Logo -->
					<div id="logo">
						<h1><a href="index.php">QRfood</a></h1>
					</div>
				
				<!-- Nav -->
					<nav id="nav">
						<ul>
							<li><a href="index.php">關於本站</a></li>
							<li><a href="foodprofile.php">食物檔案</a></li>
							<li><a href="fooddiary.php">飲食日誌</a></li>
							<li class="active"><a href="information.php">營養資訊</a></li>
							<li><a href="ctrl.php">操作說明</a></li>
							<?php
								session_start();
								if(isset($_COOKIE["uId"])){
									if(isset($_SESSION["uId"]) == $_COOKIE["uId"]){
										if($_COOKIE["role"] == 1){
							?>
											<li><a href="admin.php">管理員介面</a></li>
							<?php		}  ?>
									<li><a href="user.php">使用者資訊</a></li>
									<li><a href="logout.php">登出</a></li>
							<?php
									}
								}else{
							?>
									<li><a href="login.php">登入/註冊</a></li>
							<?php
								}
							?>
						</ul>
					</nav>

			</div>
		</div>
	<!-- Header -->
			
	<!-- Main -->
		<div id="main">
			<div class="container">
				<header>
					<h2>油脂與堅果種子類</h2>
				</header>
				<div class="box">
										
										<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;油脂與堅果種子類內含脂質及脂溶性維生素，脂質更可提供人體所需要的必需脂肪酸。在烹調過程中，油脂乃不可或缺的調味料，可有效改善食物的風味與適口性。常見的食用油分為植物油及動物油，植物油有大豆油、玉米油、葵花子油、花生油、椰子油等；動物油有豬油、牛油、雞油等，而常見的堅果種子類有瓜子、芝麻、開心果、腰果等。因動物油中含有許多飽和脂肪酸，若食用過量可能會增加罹患心血管疾病的風險，故建議國人可多選用植物油作為烹調用油。另外，需特別注意攝取油脂與堅果種子類時，建議多以堅果種子來「取代」精緻過的食用油，而非在使用食用油之外，「額外」攝取堅果種子，以免額外攝取過多熱量而不自知。衛生福利部於「每日飲食指南」建議國人每日應攝取油脂3至7茶匙及堅果種子類1份，一份油脂為5克、堅果種子為8克，一份皆為45大卡，下圖一為油脂與堅果種子類份量示意圖。</p>
										<p align="center" ><img src="images/food6.jpg" width="250" height="200" alt=""></p>
				</div>
		</div>
		</div>


	<!-- Copyright -->
		<div id="copyright">
			<div class="container">
							<ul >
								<li><img src="images/PU.PNG" width="120" height="120" alt="">
									<p> </p>
									<p class="posted">April 28, 2019  Comments</p>
								</li>
							</ul>
				Design: <a href="http://www.pu.edu.tw/">靜宜大學資訊工程學系/食品營養學系</a>
			</div>
		</div>
	</body>
</html>