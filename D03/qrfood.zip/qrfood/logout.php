<?php
	session_start();
	session_destroy();
	setcookie("uId","",time()-3600);
	setcookie("role","",time()-3600);
	header("Refresh:0;url=index.php");
?>