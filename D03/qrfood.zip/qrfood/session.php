<?php
	session_start();
	
	if($_SESSION['uId'] != null)
	{
		header('Location:addnew.html');
	}
	else
	{
		print "請先登入，跳轉至登入介面";
		header("Refresh:2;url=Login.html");
	}
?>