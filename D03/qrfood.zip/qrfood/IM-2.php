<!DOCTYPE HTML>
<html>
	<head>
		<?php include("head.html");	?>
	</head>
	<body class="homepage">

	<!-- Header -->
		<div id="header">
			<div class="container">
					
				<!-- Logo -->
					<div id="logo">
						<h1><a href="index.php">QRfood</a></h1>
					</div>
				
				<!-- Nav -->
					<nav id="nav">
						<ul>
							<li><a href="index.php">關於本站</a></li>
							<li><a href="foodprofile.php">食物檔案</a></li>
							<li><a href="fooddiary.php">飲食日誌</a></li>
							<li class="active"><a href="information.php">營養資訊</a></li>
							<li><a href="ctrl.php">操作說明</a></li>
							<?php
								session_start();
								if(isset($_COOKIE["uId"])){
									if(isset($_SESSION["uId"]) == $_COOKIE["uId"]){
										if($_COOKIE["role"] == 1){
							?>
											<li><a href="admin.php">管理員介面</a></li>
							<?php		}  ?>
									<li><a href="user.php">使用者資訊</a></li>
									<li><a href="logout.php">登出</a></li>
							<?php
									}
								}else{
							?>
									<li><a href="login.php">登入/註冊</a></li>
							<?php
								}
							?>
						</ul>
					</nav>

			</div>
		</div>
	<!-- Header -->
			
	<!-- Main -->
		<div id="main">
			<div class="container">
				<header>
					<h2>蔬菜類</h2>
				</header>
				<div class="box">
										
										<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;蔬菜類含有豐富的膳食纖維、維生素及礦物質。維生素與礦物質為人體所需要的必需營養素。膳食纖維具有增加飽足感、降低血膽固醇、調整醣類及脂肪代謝之功能，一般的建議攝取量為每日攝取20-30克。常見的蔬菜有菠菜、莧菜、油菜、地瓜葉等。衛生福利部於「每日飲食指南」建議國人每日應攝取三至五份蔬菜，一份蔬菜約為生重100克，份量大小如下圖一。一份蔬菜熱量約為25大卡，若是放在一般的白瓷碗中，大約為八分滿。根據目前的研究指出，攝取足夠蔬菜類能夠有效改善便秘、改善血脂並且幫助控制體重。</p>
										<p align="center" ><img src="images/food2.jpg" width="250" height="200" alt=""></p>
				</div>
		</div>
		</div>


	<!-- Copyright -->
		<div id="copyright">
			<div class="container">
							<ul >
								<li><img src="images/PU.PNG" width="120" height="120" alt="">
									<p> </p>
									<p class="posted">April 28, 2019  Comments</p>
								</li>
							</ul>
				Design: <a href="http://www.pu.edu.tw/">靜宜大學資訊工程學系/食品營養學系</a>
			</div>
		</div>
	</body>
</html>