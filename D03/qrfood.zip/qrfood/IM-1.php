<!DOCTYPE HTML>
<html>
	<head>
		<?php include("head.html");	?>
	</head>
	<body class="homepage">

	<!-- Header -->
		<div id="header">
			<div class="container">
					
				<!-- Logo -->
					<div id="logo">
						<h1><a href="index.php">QRfood</a></h1>
					</div>
				
				<!-- Nav -->
					<nav id="nav">
						<ul>
							<li><a href="index.php">關於本站</a></li>
							<li><a href="foodprofile.php">食物檔案</a></li>
							<li><a href="fooddiary.php">飲食日誌</a></li>
							<li class="active"><a href="information.php">營養資訊</a></li>
							<li><a href="ctrl.php">操作說明</a></li>
							<?php
								session_start();
								if(isset($_COOKIE["uId"])){
									if(isset($_SESSION["uId"]) == $_COOKIE["uId"]){
										if($_COOKIE["role"] == 1){
							?>
											<li><a href="admin.php">管理員介面</a></li>
							<?php		}  ?>
									<li><a href="user.php">使用者資訊</a></li>
									<li><a href="logout.php">登出</a></li>
							<?php
									}
								}else{
							?>
									<li><a href="login.php">登入/註冊</a></li>
							<?php
								}
							?>
						</ul>
					</nav>

			</div>
		</div>
	<!-- Header -->
			
	<!-- Main -->
		<div id="main">
			<div class="container">
				<header>
					<h2>全榖根莖類</h2>
				</header>
				<div class="box">
										
										<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;全榖根莖類食物包括各種全榖類及澱粉含量豐富的根莖類、豆類、果實，例如米飯、麵食、麵包、番薯、紅豆、綠豆等。全榖根莖類為主食，含有醣類(澱粉與膳食纖維)及少量蛋白質，主要功能為提供熱量，一份全榖根莖類能夠獲得70大卡熱量。另外，衛生福利部特別建議國人食用未過度精緻的全榖根莖類，能夠攝取到能量之外，亦能得到豐富的維生素、膳食纖維及礦物質，因此新版每日飲食指南建議主食類應以全榖或未精製的原態食物為主，至少要占主食類之三分之一。根據衛生福利部於「每日飲食指南」建議國人每日應攝取1.5至4碗全榖根莖類，份量大小如下圖。</p>
										<p align="center" ><img src="images/070.jpg" width="250" height="200"></p>
				</div>
		</div>
		</div>


	<!-- Copyright -->
		<div id="copyright">
			<div class="container">
							<ul >
								<li><img src="images/PU.PNG" width="120" height="120" alt="">
									<p> </p>
									<p class="posted">April 28, 2019  Comments</p>
								</li>
							</ul>
				Design: <a href="http://www.pu.edu.tw/">靜宜大學資訊工程學系/食品營養學系</a>
			</div>
		</div>
	</body>
</html>