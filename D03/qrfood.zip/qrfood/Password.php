<!DOCTYPE HTML>
<html>
	<head>
		<?php include("head.html");	?>
	</head>
	<style>
		body {
			font-family: Microsoft JhengHei;
		}

		.content .loginForm .line input[type='text'],
		.content .loginForm .line input[type='password'],
		.content .loginForm .line select {
			display: block;
			margin: 0 auto;
			width: 320px;
			margin-top: 12px;
			padding: 12px 15px;
			border: 1px solid #dad8d3;
			border-radius: 3px;
			line-height: 14px;
			font-size: 12px;
			background-color: #ffffff;
			margin-left: 16px;
		}

		.content {
			width: 100%;
			min-height: 450px;
			padding-bottom: 100px;
			background-color: #ffffff;
		}

		.content .title {
			margin: 0px 0 50px;
			text-align: center;
			font-size: 30px;
			font-weight: 700;
		}

		.btn {
			display: block;
			width: 320px;
			height: 36px;
			margin-left: 16px;
			margin-top: 30px;
			border: none;
			border-radius: 3px;
			border:3px double;
			text-align: center;
			vertical-align: middle;
			color: #ffffff;
			font-size: 13px;
			background-color: #1b1a1a;
			cursor: pointer;
		}

		.content .loginForm .btnLine .btn {
			width: 100%;
		}

		.content .loginForm {
			width: 360px;
			margin: 0 auto;
		}
		
		.divider {
			text-align: center;
			white-space: nowrap;
			margin-top: 10px;
			margin-bottom: 10px;
		}
	</style>

		<div id="header">
			<div class="container">
					
				<!-- Logo -->
					<div id="logo">
						<h1><a href="index.php">QRfood</a></h1>
					</div>
				
				<!-- Nav -->
					<nav id="nav">
						<ul>
							<li><a href="index.php">關於本站</a></li>
							<li><a href="foodprofile.php">食物檔案</a></li>
							<li><a href="fooddiary.php">飲食日誌</a></li>
							<li><a href="information.php">營養資訊</a></li>
							<li><a href="ctrl.php">操作說明</a></li>
							<?php
								session_start();
								if(isset($_COOKIE["uId"])){
									if(isset($_SESSION["uId"]) == $_COOKIE["uId"]){
										if($_COOKIE["role"] == 1){
							?>
											<li><a href="admin.php">管理員介面</a></li>
							<?php		}  ?>
									<li class="active"><a href="user.php">使用者資訊</a></li>
									<li><a href="logout.php">登出</a></li>
							<?php
									}
								}else{
							?>
									<li><a href="login.php">登入/註冊</a></li>
							<?php
								}
							?>
						</ul>
					</nav>

			</div>
		</div>
		
		<div id="main">
		
			<header>
				<center>
					<h2>更改密碼</h2>
				</center>
			</header>
		</div>
		

			<div class="content">
				<body>
				<form class="loginForm" name="password" method="POST" action="updatePassword.php" enctype="multipart/form-data">

			
				<div class="line">
						<div class="align">*新密碼:</div>
						<input type="password" name="password" maxlength="20"
							onkeyup="value=value.replace(/[^\a-\z\A-\Z0-9]/g,'')"
							onpaste="value=value.replace(/[^\a-\z\A-\Z0-9]/g,'')"
							oncontextmenu="value=value.replace(/[^\a-\z\A-\Z0-9]/g,'')" onchange="checkPassword()" required>
						<small id="passwordError" class="text-muted">
							密碼需要在6-20位字元內。
						</small>
				</div>
				<div class="line">
						<div class="align">*確認密碼:</div>
						<input type="password"  maxlength="20" name="confirmPassword"
							onkeyup="value=value.replace(/[^\a-\z\A-\Z0-9]/g,'')"
							onpaste="value=value.replace(/[^\a-\z\A-\Z0-9]/g,'')"
							oncontextmenu="value=value.replace(/[^\a-\z\A-\Z0-9]/g,'')" onchange="checkPassword()" required>
						<small id="confirmPasswordError" class="text-muted">
							
						</small>
				</div>

				<div>
						<input id="confirm-btn" type="submit" name="submit" value="確定更改" class="btn">
				</div>

			</form>
	</div>	
		<script>
			

			function checkPassword() {
				var result = true;
				var password = document.getElementsByName("password")[0].value;
				if (password.length < 6 | password.length > 20) {
					document.getElementById("passwordError").innerHTML = "密碼需要在6-20位字元內。";
					result = false;
				} else {
					document.getElementById("passwordError").innerHTML = "";
				}
				var confirmPassword = document.getElementsByName("confirmPassword")[0].value;
				if (password != confirmPassword) {
					document.getElementById("confirmPasswordError").innerHTML = "輸入的密碼不一致";
					result = false;
				} else {
					document.getElementById("confirmPasswordError").innerHTML = "";
				}
				return result;
			}

			function check() {
				if (checkPassword()) {
					console.log("success")
					password.submit();
				} else {
					console.log(checkPassword());
				}

			}
		</script>								

	<!-- Copyright -->
		<div id="copyright">
			<div class="container">
							<ul >
								<li><img src="images/PU.PNG" width="120" height="120" alt="">
									<p> </p>
									<p class="posted">April 28, 2019  Comments</p>
								</li>
							</ul>
				Design: <a href="http://www.pu.edu.tw/">靜宜大學資訊工程學系/食品營養學系</a>
			</div>
		</div>
	</body>
</html>