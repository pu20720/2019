<!DOCTYPE HTML>
<html>
	<head>
		<?php include("head.html");	?>
	</head>
	<style>
		body {
			font-family:Microsoft JhengHei;
		}

		.content .loginForm .line input[type='text'],
		.content .loginForm .line input[type='password'],
		.content .loginForm .line select {
			display: block;
			margin: 0 auto;
			width: 320px;
			margin-top: 12px;
			padding: 12px 15px;
			border: 1px solid #dad8d3;
			border-radius: 3px;
			line-height: 14px;
			font-size: 12px;
			background-color: #ffffff;
			margin-left: 16px;
		}

		.content {
			width: 100%;
			min-height: 450px;
			padding-bottom: 100px;
			background-color: #ffffff;
		}

		.content .title {
			margin: 0px 0 50px;
			text-align: center;
			font-size: 30px;
			font-weight: 700;
		}

		.btn {
			display: block;
			width: 320px;
			height: 36px;
			margin-left: 16px;
			margin-top: 30px;
			border: none;
			border-radius: 3px;
			border:3px double;
			text-align: center;
			vertical-align: middle;
			color: #ffffff;
			font-size: 13px;
			background-color: #1b1a1a;
			cursor: pointer;
		}

		.content .loginForm .btnLine .btn {
			width: 100%;
		}

		.content .loginForm {
			width: 360px;
			margin: 0 auto;
			font-size: 17px;
		}
		
		.divider {
			text-align: center;
			white-space: nowrap;
			margin-top: 10px;
			margin-bottom: 10px;
		}
	</style>

		<div id="header">
			<div class="container">
					
				<!-- Logo -->
					<div id="logo">
						<h1><a href="index.php">QRfood</a></h1>
					</div>
				
				<!-- Nav -->
					<nav id="nav">
						<ul>
							<li><a href="index.php">關於本站</a></li>
							<li><a href="foodprofile.php">食物檔案</a></li>
							<li><a href="fooddiary.php">飲食日誌</a></li>
							<li><a href="information.php">營養資訊</a></li>
							<li><a href="ctrl.php">操作說明</a></li>
							<?php
								session_start();
								if(isset($_COOKIE["uId"])){
									if(isset($_SESSION["uId"]) == $_COOKIE["uId"]){
										if($_COOKIE["role"] == 1){
							?>
											<li class="active"><a href="admin.php">管理員介面</a></li>
							<?php		}  ?>
									<li><a href="user.php">使用者資訊</a></li>
									<li><a href="logout.php">登出</a></li>
							<?php
									}
								}else{
							?>
									<li><a href="login.php">登入/註冊</a></li>
							<?php
								}
							?>
						</ul>
					</nav>

			</div>
		</div>

	<div id="main">	
		<header>
			<center>
				<h2>新增食物檔案</h2>
			</center>
		</header>		
	</div>
		
	<body>
		<div class="content">
		
			<form class="loginForm" name="AddNewFP" method="POST" action="adminAdd.php" enctype="multipart/form-data">

				<div class="line">
					<div class="align">*餐廳:</div>
					<?php
						include('connect.php');
						$sql = "SELECT * FROM `restaurant`";
						$result = mysqli_query($link,$sql);
					?>
					<select class="select" id="rsId" name="rsId" onchange="checkrsId()" required>
						<?php	while($row=$result->fetch_assoc()){?>
						<option value="<?php echo $row["rsId"]?>"><?php echo $row['location'],$row['rsName']?></option>
						<?php	}?>
					</select>
					<small id="rsIdError" class="text-muted">
						不能空白。
					</small>
				</div>

				<div class="line">
					<div class="align">*食物名稱:</div>
					<input type="text" name="fdName" maxlength="10" 
						onchange="checkfdName()" required>
					<small id="fdNameError" class="text-muted">
						食物名稱需要在0-10位字元內。
					</small>
				</div>
				
				<div class="line">
					<div class="align">*食物種類:</div>
					<?php
						include('connect.php');
						$sql = "SELECT * FROM `category`";
						$result = mysqli_query($link,$sql);
					?>
					<select class="select" id="cId" name="cId" onchange="checkcId()" required>
						<?php	while($row=$result->fetch_assoc()){?>
						<option value="<?php echo $row["cId"]?>"><?php echo $row['cName']?></option>
						<?php	}?>
					</select>
					<small id="cIdError" class="text-muted">
						不能空白。
					</small>
				</div>
				
				<div class="line">
					<div class="align">*克數:</div>
					<input type="text" name="gram"
						onchange="checkgram()" required>
					<small id="gramError" class="text-muted">
						不能空白。
					</small>
				</div>
				
				<div class="line">
					<div class="align">*卡路里:</div>
					<input type="text" name="calorie"
						 onchange="checkcalorie()" required>
					<small id="calorieError" class="text-muted">
						不能空白。
					</small>
				</div>
				
				<div class="line">
					<div class="align">*蛋白質:</div>
					<input type="text" name="protein"
						 onchange="checkprotein()" required>
					<small id="proteinError" class="text-muted">
						不能空白。
					</small>
				</div>
				
				<div class="line">
					<div class="align">*脂肪(總):</div>
					<input type="text" name="fat"
						 onchange="checkfat()" required>
					<small id="fatError" class="text-muted">
						不能空白。
					</small>
				</div>
				
				<div class="line">
					<div class="align">*飽和脂肪:</div>
					<input type="text" name="saturatedfat"
						 onchange="checksaturatedfat()" required>
					<small id="saturatedfatError" class="text-muted">
						不能空白。
					</small>
				</div>
				
				<div class="line">
					<div class="align">*反式脂肪:</div>
					<input type="text" name="transfat"
						 onchange="checktransfat()" required>
					<small id="transfatError" class="text-muted">
						不能空白。
					</small>
				</div>
				
				<div class="line">
					<div class="align">*膽固醇(毫克):</div>
					<input type="text" name="cholesterol"
						onchange="checkcholesterol()" required>
					<small id="cholesterolError" class="text-muted">
						不能空白。
					</small>
				</div>
				
				<div class="line">
					<div class="align">*碳水化合物(總):</div>
					<input type="text" name="carbohydrate"
						onchange="checkcarbohydrate()" required>
					<small id="carbohydrateError" class="text-muted">
						不能空白。
					</small>
				</div>
				
				<div class="line">
					<div class="align">*糖:</div>
					<input type="text" name="sugar"
						onchange="checksugar()" required>
					<small id="sugarError" class="text-muted">
						不能空白。
					</small>
				</div>
				
				<div class="line">
					<div class="align">*膳食纖維:</div>
					<input type="text" name="dietaryFiber"
						onchange="checkdietaryFiber()" required>
					<small id="dietaryFiberError" class="text-muted">
						不能空白。
					</small>
				</div>
				
				<div class="line">
					<div class="align">*納(毫克):</div>
					<input type="text" name="sodium"
						onchange="checksodium()" required>
					<small id="sodiumError" class="text-muted">
						不能空白。
					</small>
				</div>
				
				<div class="line">
					<div class="align">*鈣(毫克):</div>
					<input type="text" name="calcium"
						onchange="checkcalcium()" required>
					<small id="calciumError" class="text-muted">
						不能空白。
					</small>
				</div>
				
				<div class="line">
					<div class="align">*鉀(毫克):</div>
					<input type="text" name="potassium"
					 onchange="checkpotassium()" required>
					<small id="potassiumError" class="text-muted">
						不能空白。
					</small>
				</div>
				
				<div class="line">
					<div class="align">*鐵(毫克):</div>
					<input type="text" name="ferrum"
					 onchange="checkferrum()" required>
					<small id="ferrumError" class="text-muted">
						不能空白。
					</small>
				</div>
				
				<label>*圖片：<input type="file" name="file" ></label>
				
				<div>
					<input id="confirm-btn" type="submit" name="submit" value="送出" class="btn">
				</div>
				
			</form>
			
		</div>
		
		<script>
			function checkfdName() {
				var fdName = document.getElementsByName("fdName")[0].value;

				if (fdName.length < 0 | fdName.length > 10) {
					document.getElementById("fdNameError").innerHTML = "食物名稱需要在0-10位字元內。";
					return false;
				} else {
					document.getElementById("fdNameError").innerHTML = "";
					return true;
				}
			}

			function checkrsId() {

				var rsId = document.getElementById("rsId").value;
				if (rsId == "") {
					document.getElementById("rsIdError").innerHTML = "不能空白";
					return false;
				} else {
					document.getElementById("rsIdError").innerHTML = "";
					return true;
				}

			}
			
			function checkcId() {

				var cId = document.getElementById("cId").value;
				if (cId == "") {
					document.getElementById("cIdError").innerHTML = "不能空白";
					return false;
				} else {
					document.getElementById("cIdError").innerHTML = "";
					return true;
				}

			}
			
			function checkgram() {
				var gram = document.getElementsByName("gram")[0].value;

				if (gram.length = 0) {
					document.getElementById("gramError").innerHTML = "不能空白。";
					return false;
				} else {
					document.getElementById("gramError").innerHTML = "";
					return true;
				}
			}
			
			function checkcalorie() {
				var calorie = document.getElementsByName("calorie")[0].value;

				if (calorie.length = 0) {
					document.getElementById("calorieError").innerHTML = "不能空白。";
					return false;
				} else {
					document.getElementById("calorieError").innerHTML = "";
					return true;
				}
			}
			
			function checkprotein() {
				var protein = document.getElementsByName("protein")[0].value;

				if (protein.length = 0) {
					document.getElementById("proteinError").innerHTML = "不能空白。";
					return false;
				} else {
					document.getElementById("proteinError").innerHTML = "";
					return true;
				}
			}
			
			function checkfat() {
				var fat = document.getElementsByName("fat")[0].value;

				if (fat.length = 0) {
					document.getElementById("fatError").innerHTML = "不能空白。";
					return false;
				} else {
					document.getElementById("fatError").innerHTML = "";
					return true;
				}
			}
			
			function checksaturatedfat() {
				var saturatedfat = document.getElementsByName("saturatedfat")[0].value;

				if (saturatedfat.length = 0) {
					document.getElementById("saturatedfatError").innerHTML = "不能空白。";
					return false;
				} else {
					document.getElementById("saturatedfatError").innerHTML = "";
					return true;
				}
			}
			
			function checktransfat() {
				var transfat = document.getElementsByName("transfat")[0].value;

				if (transfat.length = 0) {
					document.getElementById("transfatError").innerHTML = "不能空白。";
					return false;
				} else {
					document.getElementById("transfatError").innerHTML = "";
					return true;
				}
			}
			
			function checkcholesterol() {
				var cholesterol = document.getElementsByName("cholesterol")[0].value;

				if (cholesterol.length = 0) {
					document.getElementById("cholesterolError").innerHTML = "不能空白。";
					return false;
				} else {
					document.getElementById("cholesterolError").innerHTML = "";
					return true;
				}
			}
			
			function checkcarbohydrate() {
				var carbohydrate = document.getElementsByName("carbohydrate")[0].value;

				if (carbohydrate.length = 0) {
					document.getElementById("carbohydrateError").innerHTML = "不能空白。";
					return false;
				} else {
					document.getElementById("carbohydrateError").innerHTML = "";
					return true;
				}
			}
			
			function checksugar() {
				var sugar = document.getElementsByName("sugar")[0].value;

				if (sugar.length = 0) {
					document.getElementById("sugarError").innerHTML = "不能空白。";
					return false;
				} else {
					document.getElementById("sugarError").innerHTML = "";
					return true;
				}
			}
			
			function checkdietaryFiber() {
				var dietaryFiber = document.getElementsByName("dietaryFiber")[0].value;

				if (dietaryFiber.length = 0) {
					document.getElementById("dietaryFiberError").innerHTML = "不能空白。";
					return false;
				} else {
					document.getElementById("dietaryFiberError").innerHTML = "";
					return true;
				}
			}
			
			function checksodium() {
				var sodium = document.getElementsByName("sodium")[0].value;

				if (sodium.length = 0) {
					document.getElementById("sodiumError").innerHTML = "不能空白。";
					return false;
				} else {
					document.getElementById("sodiumError").innerHTML = "";
					return true;
				}
			}
			
			function checkcalcium() {
				var calcium = document.getElementsByName("calcium")[0].value;

				if (calcium.length = 0) {
					document.getElementById("calciumError").innerHTML = "不能空白。";
					return false;
				} else {
					document.getElementById("calciumError").innerHTML = "";
					return true;
				}
			}
			
			function checkpotassium() {
				var potassium = document.getElementsByName("potassium")[0].value;

				if (potassium.length = 0) {
					document.getElementById("potassiumError").innerHTML = "不能空白。";
					return false;
				} else {
					document.getElementById("potassiumError").innerHTML = "";
					return true;
				}
			}
			
			function checkferrum() {
				var ferrum = document.getElementsByName("ferrum")[0].value;

				if (ferrum.length = 0) {
					document.getElementById("ferrumError").innerHTML = "不能空白。";
					return false;
				} else {
					document.getElementById("ferrumError").innerHTML = "";
					return true;
				}
			}

			
			function check() {
				if (checkfdName() & checkrsId() & checkcId() & checkgram() & checkcalorie() & checkprotein() & checkfat() & checksaturatedfat() & checktransfat() & checkcholesterol() & checkcarbohydrate() & checksugar()
					& checkdietaryFiber() & checksodium() & checkcalcium() & checkpotassium() & checkferrum()) {
					console.log("success")
					AddNewFP.submit();
				} else {
					console.log(checkfdName());
					console.log(checkrsId());
					console.log(checkcId());
					console.log(checkgram());
					console.log(checkcalorie());
					console.log(checkprotein());
					console.log(checkfat());
					console.log(checksaturatedfat());
					console.log(checktransfat());
					console.log(checkcholesterol());
					console.log(checkcarbohydrate());
					console.log(checksugar());
					console.log(checkdietaryFiber());
					console.log(checksodium());
					console.log(checkcalcium());
					console.log(checkpotassium());
					console.log(checkferrum());
				}

			}
		</script>								

	<!-- Copyright -->
		<div id="copyright">
			<div class="container">
							<ul >
								<li><img src="images/PU.PNG" width="120" height="120" alt="">
									<p> </p>
									<p class="posted">April 28, 2019  Comments</p>
								</li>
							</ul>
				Design: <a href="http://www.pu.edu.tw/">靜宜大學資訊工程學系/食品營養學系</a>
			</div>
		</div>
	</body>
</html>