<!DOCTYPE HTML>
<html>
	<head>
		<?php include("head.html");	?>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.2/Chart.min.js"></script>
	</head>
	<style>
		.calendar{
			width:450px;
			height:350px;
			background:#fff;
			box-shadow:0px 1px 1px rgba(0,0,0,0.1);
		}
		.body-list ul{
			width:100%;
			font-family:arial;
			font-weight:bold;
			font-size:14px;
		}
		.body-list ul li{
			width:14.28%;
			height:36px;
			line-height:36px;
			list-style-type:none;
			display:block;
			box-sizing:border-box;
			float:left;
			text-align:center;
		}
		.lightgrey{
			color:#a8a8a8; /*浅灰色*/
		}
		.darkgrey{
			color:#565656; /*深灰色*/
		}
		.green{
			color:#6ac13c; /*绿色*/
		}
		.greenbox{
			border:1px solid #6ac13c;
			background:#e9f8df; /*浅绿色背景*/
		}
	</style>

	<!-- Header -->
	<div id="header">
		<div class="container">

			<!-- Logo -->
					<div id="logo">
						<h1><a href="index.php">QRfood</a></h1>
					</div>
				
				<!-- Nav -->
					<nav id="nav">
						<ul>
							<li><a href="index.php">關於本站</a></li>
							<li><a href="foodprofile.php">食物檔案</a></li>
							<li class="active"><a href="fooddiary.php">飲食日誌</a></li>
							<li><a href="information.php">營養資訊</a></li>
							<li><a href="ctrl.php">操作說明</a></li>
							<?php
								include("connect.php");
								session_start();
								if(isset($_COOKIE["uId"])){
									if(isset($_SESSION["uId"]) == $_COOKIE["uId"]){
										if($_COOKIE["role"] == 1){
							?>
											<li><a href="admin.php">管理員介面</a></li>
							<?php		}  ?>
									<li><a href="user.php">使用者資訊</a></li>
									<li><a href="logout.php">登出</a></li>
							<?php
									}
								}else{
							?>
									<li><a href="login.php">登入/註冊</a></li>
							<?php
								}
							?>
						</ul>
					</nav>

		</div>
	</div>
	<!-- Header -->

	<!-- Main -->
	<div id="main">
		<div class="container">
			<header>
                <h2>飲食日誌</font></h2>
            </header>
		<body>
			<center>
			<div>
				<font size="4">
				<a href="addnew.php" class="button">新增飲食日誌</a> (更新、刪除飲食日誌內容，請直接點選食物名稱)
			</div>
			<div>
			<pre>	<?php echo $_POST['date'];?>	</pre>
			</div>
			<div>
				<?php
					if (isset($_COOKIE["uId"])) {
						$uId = $_COOKIE['uId'];
						if (isset($_SESSION["uId"]) == $_COOKIE["uId"]) {
							$date = $_POST['date'];
							$sql2 ="SELECT * FROM `record` WHERE `date` LIKE '$date'";
							$r = mysqli_query($link,$sql2);
							
							while($row=$r->fetch_assoc()){
								$sql3 = "SELECT * FROM `food` WHERE `fdId` = '$row[fdId]'";
								$r2 = mysqli_query($link,$sql3);
								if($uId == $row['uId']){
									while($row2=$r2->fetch_assoc()){
									
				?>
										<a href="\test\foodinfo.php?id=<?php	echo $row["fdId"]; ?>" id="prev" style="color:#6ac13c;"><?php	echo $row2['fdName'],"--",$row['serving'],"份","<br>";?></a>
				<?php
									}
								}
							}
				?>
			</div>

			<div>
				<ul>
					<li><strong>項目</strong></li>
				</ul>
			</div>
				<?php
					$calorie = 0;
					$protein = 0;
					$fat = 0;
					$saturatedFat = 0;
					$transFat = 0;
					$cholesterol = 0;
					$carbohydrate = 0;
					$sugar = 0;
					$dietaryFiber = 0;
					$sodium = 0;
					$calcium = 0;
					$potassium = 0;
					$ferrum = 0;
							$sql = "select * from dailyrecord";
							$result = mysqli_query($link,$sql);
							while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
								if($row['uId'] == $uId && $row['date'] == $date)
                                {
									$calorie		+= $row['calorie'];
									$protein		+= $row['protein'];
									$fat			+= $row['fat'];
									$saturatedFat	+= $row['saturatedFat'];
									$transFat		+= $row['transFat'];
									$cholesterol	+= $row['cholesterol'];
									$carbohydrate	+= $row['carbohydrate'];
									$sugar			+= $row['sugar'];
									$dietaryFiber	+= $row['dietaryFiber'];
									$sodium			+= $row['sodium'];
									$calcium		+= $row['calcium'];
									$potassium		+= $row['potassium'];
									$ferrum			+= $row['ferrum'];
								}
							}
							$sql4 = "select gender from user where uId = '$uId'";
							$rgender = mysqli_query($link,$sql4);
							$rg = mysqli_fetch_array($rgender, MYSQLI_ASSOC);
				?>

				
				<table class="table table-sm" style="text-align:center;">
			  
				  <thead>

					<tr>
					  <th scope="col">本日小計</th>
					  <td></td>
					  <th scope="col">一日所需</th>
					  <td></td>
					</tr>
					
				  </thead>
				  
				  <tbody>	
							
					<tr>
					  <th scope="row">卡路里(kcal)</th>
					  <td><?php if($rg['gender'] == 1 && $calorie > 2400 || $rg['gender'] == 2 && $calorie > 1900){echo $calorie;}else{?><font color="red"><?php echo $calorie ;}?></font></td>
					  <th scope="row">卡路里(kcal)</th>
					  <td><?php if($rg['gender'] == 1){echo '2,400'; } else{echo '1,900';}?></td>
					</tr>
					
					<tr>
					  <th scope="row">蛋白質(g)</th>
					  <td><?php if($rg['gender'] == 1 && $protein > 50 || $rg['gender'] == 2 && $protein > 63.3){echo $protein;}else{?><font color="red"><?php echo $protein ;}?></font></td>
					  <th scope="row">蛋白質(g)</th>
					  <td><?php if($rg['gender'] == 1){echo '50'; } else{echo '63.3';}?></td>
					</tr>
					
					<tr>
					  <th scope="row">脂肪(g)</th>
					  <td><?php if($rg['gender'] == 1 && $fat > 80 || $rg['gender'] == 2 && $fat > 63.3){echo $fat;}else{?><font color="red"><?php echo $fat ;}?></font></td>
					  <th scope="row">脂肪(g)</th>
					  <td><?php if($rg['gender'] == 1){echo '80'; } else{echo '63.3';}?></td>
					</tr>
					
					<tr>
					  <th scope="row">飽和脂肪(g)</th>
					  <td><?php if($rg['gender'] == 1 && $saturatedFat > 23 || $rg['gender'] == 2 && $saturatedFat > 18){echo $saturatedFat;}else{?><font color="red"><?php echo $saturatedFat ;}?></font></td>
					  <th scope="row">飽和脂肪(g)</th>
					  <td><?php if($rg['gender'] == 1){echo '<23'; } else{echo '<18';}?></td>
					</tr>
					
					<tr>
					  <th scope="row">反式脂肪(g)</th>
					  <td><?php if($rg['gender'] == 1 && $transFat > 0 || $rg['gender'] == 2 && $transFat > 0){echo $transFat;}else{?><font color="red"><?php echo $transFat ;}?></font></td>
					  <th scope="row">反式脂肪(g)</th>
					  <td><?php if($rg['gender'] == 1){echo '0'; } else{echo '0';} ?></td>
					</tr>
					
					<tr>
					  <th scope="row">膽固醇(mg)</th>
					  <td><?php if($rg['gender'] == 1 && $cholesterol > 300 || $rg['gender'] == 2 && $cholesterol > 300){echo $cholesterol;}else{?><font color="red"><?php echo $cholesterol ;}?></font></td>
					  <th scope="row">膽固醇(mg)</th>
					  <td><?php if($rg['gender'] == 1){echo '<300'; } else{echo '<300';}?></td>
					</tr>
					
					<tr>
					  <th scope="row">碳水化合物(g)</th>
					  <td><?php if($rg['gender'] == 1 && $carbohydrate > 360 || $rg['gender'] == 2 && $carbohydrate > 285){echo $carbohydrate;}else{?><font color="red"><?php echo $carbohydrate ;}?></font></td>
					  <th scope="row">碳水化合物(g)</th>
					  <td><?php if($rg['gender'] == 1){echo '<360'; } else{echo '<285';}?></td>
					</tr>
					
					<tr>
					  <th scope="row">糖(g)</th>
					  <td><?php if($rg['gender'] == 1 && $sugar > 60 || $rg['gender'] == 2 && $sugar > 47.5){echo $sugar;}else{?><font color="red"><?php echo $sugar ;}?></font></td>
					  <th scope="row">糖(g)</th>
					  <td><?php if($rg['gender'] == 1){echo '<60'; } else{echo '<47.5';}?></td>
					</tr>
					
					<tr>
					  <th scope="row">膳食纖維(g)</th>
					  <td><?php if($rg['gender'] == 1 && $dietaryFiber > 35 || $rg['gender'] == 2 && $dietaryFiber > 28){echo $dietaryFiber;}else{?><font color="red"><?php echo $dietaryFiber ;}?></font></td>
					  <th scope="row">膳食纖維(g)</th>
					  <td><?php if($rg['gender'] == 1){echo '35'; } else{echo '28';}?></td>
					</tr>
					
					<tr>
					  <th scope="row">鈉(mg)</th>
					  <td><?php if($rg['gender'] == 1 && $sodium > 2400 || $rg['gender'] == 2 && $sodium > 2400){echo $sodium;}else{?><font color="red"><?php echo $sodium ;}?></font></td>
					  <th scope="row">鈉(mg)</th>
					  <td><?php if($rg['gender'] == 1){echo '<2,400'; } else{echo '<2,400';}?></td>
					</tr>
					
					<tr>
					  <th scope="row">鈣(mg)</th>
					  <td><?php if($rg['gender'] == 1 && $calcium > 1000 || $rg['gender'] == 2 && $calcium > 1000){echo $calcium;}else{?><font color="red"><?php echo $calcium ;}?></font></td>
					  <th scope="row">鈣(mg)</th>
					  <td><?php if($rg['gender'] == 1){echo '1,000'; } else{echo '1,000';}?></td>
					</tr>
					
					<tr>
					  <th scope="row">鉀(mg)</th>
					  <td><?php if($rg['gender'] == 1 && $potassium > 4700 || $rg['gender'] == 2 && $potassium > 4700){echo $potassium;}else{?><font color="red"><?php echo $potassium ;}?></font></td>
					  <th scope="row">鉀(mg)</th>
					  <td><?php if($rg['gender'] == 1){echo '4,700'; } else{echo '4,700';}?></td>
					</tr>
					
					<tr>
					  <th scope="row">鐵(mg)</th>
					  <td><?php if($rg['gender'] == 1 && $ferrum > 10 || $rg['gender'] == 2 && $ferrum > 15){echo $ferrum;}else{?><font color="red"><?php echo $ferrum ;}?></font></td>
					  <th scope="row">鐵(mg)</th>
					  <td><?php if($rg['gender'] == 1){echo '10'; } else{echo '15';}?></td>
					</tr>
					
					
					
				  </tbody>
				  
				</table>
				<a href="otherrecord.php" class="button">查看他日飲食</a>
			</font>
				<canvas id="chart" width="800" height="600"></canvas>
			<?php
						}
					}
					?>
	</div>
		</div>
</div>
		<script>
				var ctx = document.getElementById('chart').getContext('2d');

				var chart = new Chart(ctx, {
					type: 'bar',
					data: {
						labels: ["卡路里(kcal)", "蛋白質(g)", "脂肪(g)", "飽和脂肪(g)", "反式脂肪(g)", "膽固醇(mg)", "碳水化合物(g)", "糖(g)", "膳食纖維(g)", "鈉(mg)", "鈣(mg)", "鉀(mg)", "鐵(mg)"],
						datasets: [{
							label: '本日小計',
							data: [<?php echo $calorie;?>,,<?php echo $protein;?>,<?php echo $fat;?>, <?php echo $saturatedFat;?>, <?php echo $transFat;?>, <?php echo $cholesterol;?>, 
									<?php echo $carbohydrate;?>,<?php echo $sugar;?>, <?php echo $dietaryFiber;?>, <?php echo $sodium;?>, <?php echo $calcium;?>, <?php echo $potassium;?>, <?php echo $ferrum;?>],
							backgroundColor: [
								'rgba(255, 99, 132, 0.2)',
								'rgba(54, 162, 235, 0.2)',
								'rgba(255, 206, 86, 0.2)',
								'rgba(75, 192, 192, 0.2)',
								'rgba(153, 102, 255, 0.2)',
								'rgba(255, 159, 64, 0.2)',
								'rgba(255, 99, 132, 0.2)',
								'rgba(54, 162, 235, 0.2)',
								'rgba(255, 206, 86, 0.2)',
								'rgba(75, 192, 192, 0.2)',
								'rgba(153, 102, 255, 0.2)',
								'rgba(255, 159, 64, 0.2)',
								'rgba(255, 99, 132, 0.2)'
								
							],
							borderColor: [
								'rgba(255,99,132,1)',
								'rgba(54, 162, 235, 1)',
								'rgba(255, 206, 86, 1)',
								'rgba(75, 192, 192, 1)',
								'rgba(153, 102, 255, 1)',
								'rgba(255, 159, 64, 1)',
								'rgba(255,99,132,1)',
								'rgba(54, 162, 235, 1)',
								'rgba(255, 206, 86, 1)',
								'rgba(75, 192, 192, 1)',
								'rgba(153, 102, 255, 1)',
								'rgba(255, 159, 64, 1)',
								'rgba(255,99,132,1)'
							],
							borderWidth: 1
						}]
					}
				});
		</script>

	<!-- Copyright -->
	<div id="copyright">
			<div class="container">
							<ul >
								<li><img src="images/PU.PNG" width="120" height="120" alt="">
									<p> </p>
									<p class="posted">April 28, 2019  Comments</p>
								</li>
							</ul>
				Design: <a href="http://www.pu.edu.tw/">靜宜大學資訊工程學系/食品營養學系</a>
			</div>
		</div>
	</body>
</html>