<?php		
	include('loginAPI.php');
		
		if (isset($_SESSION['uId']) == $userInfo['uId'] && $userInfo['uId'] != null) {
			setcookie("uId",$userInfo['uId'],time() + 3600);
			setcookie("role",$userInfo['role'],time() + 3600);
			header("Refresh:0;url=index.php");
		}
		else {
			print "登入失敗，請檢查帳號密碼。";
			header("Refresh:1;url=Login.php");
		}
?>