<?php
	include("connect.php");
	
	$name = $_POST['name'];
	$gender = $_POST['gender'];
	$email = $_POST['email'];
	$height = $_POST['height'];
	$weight = $_POST['weight'];
	$exercise = $_POST['exercise'];
	
	session_start();

if(isset($_COOKIE["uId"])){
	if(isset($_SESSION["uId"]) == $_COOKIE["uId"])
	{
		
			$sql = "SELECT * FROM user WHERE uId='";
			$sql.=$_COOKIE["uId"]."'";
			$userInfo = mysqli_query($link, $sql);
			$userInfo = mysqli_fetch_assoc ($userInfo);
			$uId = $_COOKIE['uId'];
			
			$sql = "UPDATE `user` SET `name`= '$name' ,`email`= '$email' ,`gender`= '$gender' ,`height`= $height ,`weight`= $weight ,`exercise`= $exercise WHERE uId = $uId";
			$r = mysqli_query($link, $sql);
			
			if(mysqli_query($link, $sql))
			{
					setcookie('check','1',time()+3);
					header("Refresh:0;url=user.php");
			}
			else
			{
					setcookie('check','2',time()+3);
					header("Refresh:0;url=user.php");
			}
		mysqli_close($link);
	}
	else
	{
			echo "尚未登入。";
			header("Refresh:0;url=login.php");
	}
		
}
else
{
	echo "未偵測到COOKIE,請確認COOKIE開啟後再重新登入。";
	header("Refresh:0;url=login.php");
}
?>
	
	