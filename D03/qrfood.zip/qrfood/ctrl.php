<!DOCTYPE HTML>
<html>
	<head>
		<?php include("head.html");	?>
	</head>
	<body>

	<!-- Header -->
		<div id="header">
			<div class="container">
					
				<!-- Logo -->
					<div id="logo">
						<h1><a href="index.php">QRfood</a></h1>
					</div>
				
				<!-- Nav -->
					<nav id="nav">
						<ul>
							<li><a href="index.php">關於本站</a></li>
							<li><a href="foodprofile.php">食物檔案</a></li>
							<li><a href="fooddiary.php">飲食日誌</a></li>
							<li><a href="information.php">營養資訊</a></li>
							<li class="active"><a href="ctrl.php">操作說明</a></li>
							<?php
								session_start();
								if(isset($_COOKIE["uId"])){
									if(isset($_SESSION["uId"]) == $_COOKIE["uId"]){
										if($_COOKIE["role"] == 1){
							?>
											<li><a href="admin.php">管理員介面</a></li>
							<?php		}  ?>
									<li><a href="user.php">使用者資訊</a></li>
									<li><a href="logout.php">登出</a></li>
							<?php
									}
								}else{
							?>
									<li><a href="login.php">登入/註冊</a></li>
							<?php
								}
							?>
						</ul>
					</nav>

			</div>
		</div>
	<!-- Header -->
			
	<!-- Main -->
		<div id="main">
			<div class="container">
			
			<header>
				<h2>操作說明</h2>
			</header>
			
					<!-- Content -->
						<div style="font-size:18px;">
						跟著以下步驟，登入註冊後即可立即開始記錄自己的飲食生活喔。<br>
						(本網站同時也有APP版本可供使用。)
						<br>
						<br>
						<br>						
						STEP.1
							進入<a href="register.php" style="color:blue;">註冊</a>頁面，填妥個人資訊並<a href="login.php" style="color:blue;">登入</a><br><br>
							<center><img src="images/ctrl1.JPG" width="80%" height="80%"></center>
						<br>
						<br>
						<br>
						STEP.2
							進入使用者資訊</a>頁面，確認資料填寫無誤<br><br>
							<center><img src="images/ctrl2.JPG" width="80%" height="80%"></center>
						<br>
						<br>
						<br>
						STEP.3
							接著便可進入<a href="addnew.php" style="color:blue;">新增飲食日誌</a>頁面，開始紀錄飲食情況並在<a href="fooddiary.php" style="color:blue;">飲食日誌</a>頁面進行查看囉<br><br>
							<center><img src="images/ctrl3.JPG" width="80%" height="80%"></center>
		
						</div>
					<!-- /Content -->
			</div>
		</div>

	<!-- Copyright -->
		<div id="copyright">
			<div class="container">
							<ul >
								<li><img src="images/PU.PNG" width="120" height="120" alt="">
									<p> </p>
									<p class="posted">April 28, 2019  Comments</p>
								</li>
							</ul>
				Design: <a href="http://www.pu.edu.tw/">靜宜大學資訊工程學系/食品營養學系</a>
			</div>
		</div>
	</body>
</html>