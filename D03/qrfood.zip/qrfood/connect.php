<?php
	$DBUSER = "root411";
	$DBPASSWD = "root411root41";
	$DBHOST = "localhost";
	$DBNAME = "qrfood";
	
	$link = mysqli_connect($DBHOST,$DBUSER,$DBPASSWD,$DBNAME);
	mysqli_query( $link, "SET NAMES 'utf8'");
?>