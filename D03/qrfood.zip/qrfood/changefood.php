<!DOCTYPE HTML>
<html>
	<head>
		<?php include("head.html");	?>
	</head>
	<body class="homepage">

	<!-- Header -->
		<div id="header">
			<div class="container">
					
				<!-- Logo -->
					<div id="logo">
						<h1><a href="index.php">QRfood</a></h1>
					</div>
				
				<!-- Nav -->
					<nav id="nav">
						<ul>
							<li><a href="index.php">關於本站</a></li>
							<li><a href="foodprofile.php">食物檔案</a></li>
							<li><a href="fooddiary.php">飲食日誌</a></li>
							<li class="active"><a href="information.php">營養資訊</a></li>
							<li><a href="ctrl.php">操作說明</a></li>
							<?php
								session_start();
								if(isset($_COOKIE["uId"])){
									if(isset($_SESSION["uId"]) == $_COOKIE["uId"]){
										if($_COOKIE["role"] == 1){
							?>
											<li><a href="admin.php">管理員介面</a></li>
							<?php		}  ?>
									<li><a href="user.php">使用者資訊</a></li>
									<li><a href="logout.php">登出</a></li>
							<?php
									}
								}else{
							?>
									<li><a href="login.php">登入/註冊</a></li>
							<?php
								}
							?>
						</ul>
					</nav>

			</div>
		</div>
	<!-- Header -->
			
	<!-- Main -->
		<div id="main">
			<div class="container">
				<header>
					<h2>食物代換</h2>
				</header>
				<div class="box">
										
					<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;依照「每日飲食指南」的飲食攝取建議，每天全穀根莖類需攝取1.5至4碗，豆魚肉蛋類4至12份，蔬菜類3至6份，水果類2至5份，低脂乳品類1.5至2杯，
						油脂需4至7茶匙，堅果與種子類1份。全榖根莖類只有白飯與麵條嗎？其實每一類的食物裡面都有很多營養素含量相近的食物，同一類的食物，每一份量裡面
						所含有的熱量與營養素都很相似，因此可以互相代換，以增加菜色的多樣性，豐富我們的飲食喔！舉例說明如下：
					</p>
					
						&emsp;1.全穀根莖類：1.5至4碗<p>&emsp;使用工具為一般家用白瓷碗。以下標示重量為可食重量。<p>
						&emsp;糙米飯1碗(200公克)=白米飯1碗<p>
					<li>
						稀飯2碗=熟麵條2碗
					</li>
					<li>
						麥粉、燕麥、麥片、米80公克
					</li>
					<li>
						全麥吐司、全麥大饅頭100公克<p>
					</li>
					&emsp;2.豆魚肉蛋類：3至8份<p>
					&emsp;使用工具為手掌。高大男性手掌約5份，普通男性、女性手掌約4份，
					部分女性手掌較小約3份。以下標示重量為可食重量。<br>
					&emsp;一份的去皮雞胸肉、牛排、里肌肉、肉燥重量約30公克<p>
					&emsp;= 雞蛋1顆(65公克)<p>
					&emsp;= 草蝦30公克(約4隻)<p>
					&emsp;= 豆漿260毫升 =傳統豆腐80公克 =嫩豆腐140公克約半盒<p>
					&emsp;3.蔬菜類：3至5份<br>
					&emsp;使用工具為一般家用白瓷碗。煮熟後一份蔬菜約半碗。<p>
					&emsp;蔬菜部分可食重量皆為100公克。<p>
					&emsp;4.水果類：2至4份<br>
					&emsp;使用工具為一般家用白瓷碗。一份水果約八分滿。<p>
					&emsp;5.低脂乳品類：1.5至2杯<br>
					&emsp;以下標示重量為可食重量。<p>
					&emsp;低脂或脫脂牛奶240毫升=低脂或脫脂奶粉25公克<p>
					&emsp;油脂類：3至7茶匙；堅果與種子類：1份<p>
					&emsp;一份油脂=1小茶匙植物油(5公克)<p>
					&emsp;一份堅果種子類約10公克<p>
				</div>
		</div>
		</div>

	<!-- Copyright -->
		<div id="copyright">
			<div class="container">
							<ul >
								<li><img src="images/PU.PNG" width="120" height="120" alt="">
									<p> </p>
									<p class="posted">April 28, 2019  Comments</p>
								</li>
							</ul>
				Design: <a href="http://www.pu.edu.tw/">靜宜大學資訊工程學系/食品營養學系</a>
			</div>
		</div>
	</body>
</html>