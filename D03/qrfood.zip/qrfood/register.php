<!DOCTYPE HTML>
<html>
	<head>
		<?php include("head.html");	?>
	</head>
	<style>
		body {
			font-family:Microsoft JhengHei;
		}

		.content .loginForm .line input[type='text'],
		.content .loginForm .line input[type='password'],
		.content .loginForm .line select {
			display: block;
			margin: 0 auto;
			width: 320px;
			margin-top: 12px;
			padding: 12px 15px;
			border: 1px solid #dad8d3;
			border-radius: 3px;
			line-height: 14px;
			font-size: 12px;
			background-color: #ffffff;
			margin-left: 16px;
		}

		.content {
			width: 100%;
			min-height: 450px;
			padding-bottom: 100px;
			background-color: #ffffff;
		}

		.content .title {
			margin: 0px 0 50px;
			text-align: center;
			font-size: 30px;
			font-weight: 700;
		}

		.btn {
			display: block;
			width: 320px;
			height: 36px;
			margin-left: 16px;
			margin-top: 30px;
			border: none;
			border-radius: 3px;
			border:3px double;
			text-align: center;
			vertical-align: middle;
			color: #ffffff;
			font-size: 13px;
			background-color: #1b1a1a;
			cursor: pointer;
		}

		.content .loginForm .btnLine .btn {
			width: 100%;
		}

		.content .loginForm {
			width: 360px;
			margin: 0 auto;
			font-size: 17px;
		}
		
		.divider {
			text-align: center;
			white-space: nowrap;
			margin-top: 10px;
			margin-bottom: 10px;
		}
	</style>

		<div id="header">
			<div class="container">
					
				<!-- Logo -->
					<div id="logo">
						<h1><a href="index.php">QRfood</a></h1>
					</div>
				
				<!-- Nav -->
					<nav id="nav">
						<ul>
							<li><a href="index.php">關於本站</a></li>
							<li><a href="foodprofile.php">食物檔案</a></li>
							<li><a href="fooddiary.php">飲食日誌</a></li>
							<li><a href="information.php">營養資訊</a></li>
							<li><a href="ctrl.php">操作說明</a></li>
							<?php
								session_start();
								if(isset($_COOKIE["uId"])){
									if(isset($_SESSION["uId"]) == $_COOKIE["uId"]){
										if($_COOKIE["role"] == 1){
							?>
											<li><a href="admin.php">管理員介面</a></li>
							<?php		}  ?>
									<li><a href="user.php">使用者資訊</a></li>
									<li><a href="logout.php">登出</a></li>
							<?php
									}
								}else{
							?>
									<li class="active"><a href="login.php">登入/註冊</a></li>
							<?php
								}
							?>
						</ul>
					</nav>

			</div>
		</div>

		<div id="main">
			<header>
				<center>
					<h2>註冊</h2>
				</center>
			</header>
		</div>
		
			<body>
		<div class="content">
			<form class="loginForm" name="register" method="POST" action="register_new.php" enctype="multipart/form-data">

			

				<div class="line">
					<div class="align">*帳號:</div>
					<input type="text" name="account" maxlength="20" 
						onkeyup="value=value.replace(/[^\a-\z\A-\Z0-9]/g,'')"
						onpaste="value=value.replace(/[^\a-\z\A-\Z0-9]/g,'')"
						oncontextmenu="value=value.replace(/[^\a-\z\A-\Z0-9]/g,'')" onchange="checkAccount()" required>
					<small id="accountError" class="text-muted">
						帳號需要在6-20位字元內。
					</small>
					</div>
					<div class="line">
						<div class="align">*密碼:</div>
						<input type="password" name="password" maxlength="20"
							onkeyup="value=value.replace(/[^\a-\z\A-\Z0-9]/g,'')"
							onpaste="value=value.replace(/[^\a-\z\A-\Z0-9]/g,'')"
							oncontextmenu="value=value.replace(/[^\a-\z\A-\Z0-9]/g,'')" onchange="checkPassword()" required>
						<small id="passwordError" class="text-muted">
							密碼需要在6-20位字元內。
						</small>
					</div>
					<div class="line">
						<div class="align">*確認密碼:</div>
						<input type="password"  maxlength="20" name="confirmPassword"
							onkeyup="value=value.replace(/[^\a-\z\A-\Z0-9]/g,'')"
							onpaste="value=value.replace(/[^\a-\z\A-\Z0-9]/g,'')"
							oncontextmenu="value=value.replace(/[^\a-\z\A-\Z0-9]/g,'')" onchange="checkPassword()" required>
						<small id="confirmPasswordError" class="text-muted">
							
						</small>
					</div>
					<div class="line">
						<div class="align">*姓名:</div>
						<input type="text" name="name" class="form-control mx-sm-3" required>

					</div>
					<div class="line">
						<div class="align">*性別:</div>
						<select class="select" id="gender" name="gender" onchange="checkGender()" required>
							<option selected></option>
							<option value="1">男</option>
							<option value="2">女</option>
						</select>
						<small id="genderError" class="text-muted">

						</small>
					</div>

					<div class="line">
						<div class="align">*信箱:</div>
						<input type="text" name="email" class="form-control mx-sm-3">
					</div>
					
					<div class="line">
						<div class="align">*身高(公分):</div>
						<input type="text" name="height" maxlength="3" 
							onchange="checkHeight()" required>
						<small id="heightError" class="text-muted">
							身高需要在3位字元內。
						</small>
					</div>
					
					<div class="line">
						<div class="align">*體重(公斤):</div>
						<input type="text" name="weight" maxlength="3" 
							 onchange="checkWeight()" required>
						<small id="weightError" class="text-muted">
							體重需要在3位字元內。
						</small>
					</div>
					
					<div class="line">
						<div class="align">*運動量:</div>
						<input type="text" name="exercise" maxlength="3" 
							 onchange="checkExercise()" required>
						<small id="weightError" class="text-muted">
							運動量需要在3位字元內。
						</small>
					</div>


					<div>
							<input id="confirm-btn" type="submit" name="submit" value="立刻註冊" class="btn" >
					</div>

				     <div class="divider"><span>已經擁有帳戶？</span></div>
					 
					<div>
						<input id="confirm-btn" name="register" type="button" value="登入"  onclick="location.href='login.php'" class="btn">
					</div>
			</form>
	</div>
		<script>
			function checkAccount() {
				var account = document.getElementsByName("account")[0].value;

				if (account.length < 6 | account.length > 20) {
					document.getElementById("accountError").innerHTML = "帳號需要在6-20位字元內。";
					return false;
				} else {
					document.getElementById("accountError").innerHTML = "";
					return true;
				}
			}

			function checkPassword() {
				var result = true;
				var password = document.getElementsByName("password")[0].value;
				if (password.length < 6 | password.length > 20) {
					document.getElementById("passwordError").innerHTML = "密碼需要在6-20位字元內。";
					result = false;
				} else {
					document.getElementById("passwordError").innerHTML = "";
				}
				var confirmPassword = document.getElementsByName("confirmPassword")[0].value;
				if (password != confirmPassword) {
					document.getElementById("confirmPasswordError").innerHTML = "輸入的密碼不一致";
					result = false;
				} else {
					document.getElementById("confirmPasswordError").innerHTML = "";
				}
				return result;
			}

			function checkGender() {

				var gender = document.getElementById("gender").value;
				if (gender == "") {
					document.getElementById("genderError").innerHTML = "不能空白";
					return false;
				} else {
					document.getElementById("genderError").innerHTML = "";
					return true;
				}

			}
			
			function checkHeight() {
				var height = document.getElementsByName("height")[0].value;

				if (height.length < 1 | height.length > 3) {
					document.getElementById("heightError").innerHTML = "身高需要在3位字元內。";
					return false;
				} else {
					document.getElementById("heightError").innerHTML = "";
					return true;
				}
			}
			
			function checkWeight() {
				var weight = document.getElementsByName("weight")[0].value;

				if (weight.length < 1 | weight.length > 3){
					document.getElementById("weightError").innerHTML = "體重需要在3位字元內。";
					return false;
				} else {
					document.getElementById("weightError").innerHTML = "";
					return true;
				}
			}
			
			function checkExercise() {
				var exercise = document.getElementsByName("exercise")[0].value;

				if (exercise.length < 1 | exercise.length > 3) {
					document.getElementById("exerciseError").innerHTML = "運動量需要在3位字元內。";
					return false;
				} else {
					document.getElementById("exerciseError").innerHTML = "";
					return true;
				}
			}

			function check() {
				if (checkAccount() & checkPassword() & checkGender() & checkHeight() & checkWeight() & checkExercise()) {
					console.log("success")
					register.submit();
				} else {
					console.log(checkAccount());
					console.log(checkPassword());
					console.log(checkGender());
					console.log(checkHeight());
					console.log(checkWeight());
					console.log(checkExercise());
				}

			}
		</script>								
	
	<div id="copyright">
			<div class="container">
							<ul >
								<li><img src="images/PU.PNG" width="120" height="120" alt="">
									<p> </p>
									<p class="posted">April 28, 2019  Comments</p>
								</li>
							</ul>
				Design: <a href="http://www.pu.edu.tw/">靜宜大學資訊工程學系/食品營養學系</a>
			</div>
	</div>
	
	</body>
</html>