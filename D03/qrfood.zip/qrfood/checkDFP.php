<!DOCTYPE HTML>
<html>
	<head>
		<?php include("head.html");	?>
	</head>
	
	<body class="homepage">

	<!-- Header -->
		<div id="header">
				<!-- Logo -->
					<div id="logo">
						<h1><a href="index.php">QRfood</a></h1>
					</div>
				
				<!-- Nav -->
					<nav id="nav">
						<ul>
							<li><a href="index.php">關於本站</a></li>
							<li><a href="foodprofile.php">食物檔案</a></li>
							<li><a href="fooddiary.php">飲食日誌</a></li>
							<li><a href="information.php">營養資訊</a></li>
							<li><a href="ctrl.php">操作說明</a></li>
							<?php
								session_start();
								if(isset($_COOKIE["uId"])){
									if(isset($_SESSION["uId"]) == $_COOKIE["uId"]){
										if($_COOKIE["role"] == 1){
							?>
											<li class="active"><a href="admin.php">管理員介面</a></li>
							<?php		}  ?>
									<li><a href="user.php">使用者資訊</a></li>
									<li><a href="logout.php">登出</a></li>
							<?php
									}
								}else{
							?>
									<li><a href="login.php">登入/註冊</a></li>
							<?php
								}
							?>
						</ul>
					</nav>
		</div>
	<!-- Header -->
			
	<!-- Main -->
		<div id="main">
				<header>
					<h2>食物營養成分</h2>
				</header>
				<?php
					$fdId = $_GET["id"];
					
					include('connect.php');
					
					$sql = "SELECT *  FROM `food` WHERE `fdId` = '$fdId' ";
					$result = mysqli_query($link,$sql);
					$row = mysqli_fetch_assoc($result);
					$no="查無資料";
			
					$a="";
					$a2="";
					$b="";
					
					$sql2 = "SELECT * FROM `restaurant`";
					$result2 = mysqli_query($link,$sql2);
					
					$sql3 = "SELECT * FROM `restaurant`";
					$result3 = mysqli_query($link,$sql3);
				?>
			
			<table class="table table-sm" style="text-align:center;">
			  
			  <thead>
				
				<tr>
				  <th scope="col">食物名稱</th>
				  <td><?php if($row!=null){echo $row["fdName"];} else{echo $no;} ?></td>
				</tr>
				
			  </thead>
			  
			  <tbody>
				
				<tr>
				  <th scope="row">克數</th>
				  <td><?php if($row!=null){echo $row["gram"];} else{echo $no;} ?></td>
				</tr>
				
				<tr>
				  <th scope="row">卡路里</th>
				  <td><?php if($row!=null){echo $row["calorie"];} else{echo $no;} ?></td>
				</tr>
				
				<tr>
				  <th scope="row">蛋白質</th>
				  <td><?php if($row!=null){echo $row["protein"];} else{echo $no;} ?></td>
				</tr>
				
				<tr>
				  <th scope="row">脂肪(總)</th>
				  <td><?php if($row!=null){echo $row["fat"];} else{echo $no;} ?></td>
				</tr>
				
				<tr>
				  <th scope="row">飽和脂肪</th>
				  <td><?php if($row!=null){echo $row["saturatedFat"];} else{echo $no;} ?></td>
				</tr>
				
				<tr>
				  <th scope="row">反式脂肪</th>
				  <td><?php if($row!=null){echo $row["transFat"];} else{echo $no;} ?></td>
				</tr>
				
				<tr>
				  <th scope="row">膽固醇(毫克)</th>
				  <td><?php if($row!=null){echo $row["cholesterol"];} else{echo $no;} ?></td>
				</tr>
				
				<tr>
				  <th scope="row">碳水化合物(總)</th>
				  <td><?php if($row!=null){echo $row["carbohydrate"];} else{echo $no;} ?></td>
				</tr>
				
				<tr>
				  <th scope="row">糖</th>
				  <td><?php if($row!=null){echo $row["sugar"];} else{echo $no;} ?></td>
				</tr>
				
				<tr>
				  <th scope="row">膳食纖維</th>
				  <td><?php if($row!=null){echo $row["dietaryFiber"];} else{echo $no;} ?></td>
				</tr>
				
				<tr>
				  <th scope="row">鈉(毫克)</th>
				  <td><?php if($row!=null){echo $row["sodium"];} else{echo $no;} ?></td>
				</tr>
				
				<tr>
				  <th scope="row">鈣(毫克)</th>
				  <td><?php if($row!=null){echo $row["calcium"];} else{echo $no;} ?></td>
				</tr>
				
				<tr>
				  <th scope="row">鉀(毫克)</th>
				  <td><?php if($row!=null){echo $row["potassium"];} else{echo $no;} ?></td>
				</tr>
				
				<tr>
				  <th scope="row">鐵(毫克)</th>
				  <td><?php if($row!=null){echo $row["ferrum"];} else{echo $no;} ?></td>
				</tr>
				
				<tr>
				  <th scope="row">圖片</th>
				  <td><img src=<?php echo $row["photo"] ?> width="150" height="150"></td>
				</tr>
				
			  </tbody>
			  
			</table>
			
			<form action="adminDelete.php" method="post" style="text-align:center">
								
				餐廳:<select class="select" id="rsId" name="rsId">
						<?php
							while($row2=$result2->fetch_assoc()){
								if($row['rsId'] == $row2['rsId']){
									$a=$row2['location'];
									$a2=$row2['rsName'];
								}
							}
						?>
							<option value="<?php echo $row["rsId"];?>"><?php if($row!=null){echo $a,$a2; }	else{echo $no;}?></option>
						
					</select>
				菜名：<input type="text" name="fdName" value="<?php if($row!=null){echo $row["fdName"];} ?>" >
								<input type="submit" name="DFP" value="確認刪除" class="button">
				
			</form>
			
			
		</div>
		
	<!-- Copyright -->
		<div id="copyright">
			<div class="container">
							<ul >
								<li><img src="images/PU.PNG" width="120" height="120" alt="">
									<p> </p>
									<p class="posted">April 28, 2019  Comments</p>
								</li>
							</ul>
				Design: <a href="http://www.pu.edu.tw/">靜宜大學資訊工程學系/食品營養學系</a>
			</div>
		</div>
	</body>
</html>