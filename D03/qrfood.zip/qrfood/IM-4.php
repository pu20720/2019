<!DOCTYPE HTML>
<html>
	<head>
		<?php include("head.html");	?>
	</head>
	<body class="homepage">

	<!-- Header -->
		<div id="header">
			<div class="container">
					
				<!-- Logo -->
					<div id="logo">
						<h1><a href="index.php">QRfood</a></h1>
					</div>
				
				<!-- Nav -->
					<nav id="nav">
						<ul>
							<li><a href="index.php">關於本站</a></li>
							<li><a href="foodprofile.php">食物檔案</a></li>
							<li><a href="fooddiary.php">飲食日誌</a></li>
							<li class="active"><a href="information.php">營養資訊</a></li>
							<li><a href="ctrl.php">操作說明</a></li>
							<?php
								session_start();
								if(isset($_COOKIE["uId"])){
									if(isset($_SESSION["uId"]) == $_COOKIE["uId"]){
										if($_COOKIE["role"] == 1){
							?>
											<li><a href="admin.php">管理員介面</a></li>
							<?php		}  ?>
									<li><a href="user.php">使用者資訊</a></li>
									<li><a href="logout.php">登出</a></li>
							<?php
									}
								}else{
							?>
									<li><a href="login.php">登入/註冊</a></li>
							<?php
								}
							?>
						</ul>
					</nav>

			</div>
		</div>
	<!-- Header -->
			
	<!-- Main -->
		<div id="main">
			<div class="container">
				<header>
					<h2>豆魚肉蛋類</h2>
				</header>
				<div class="box">
										
										<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;豆魚肉蛋類主要提供蛋白質。蛋白質是構成肌肉、器官等的主要材料 ，同時也是骨骼、皮膚、牙齒、頭髮等的基本原料，還有調節生理機能、供給熱量之功能。構成蛋白質之單元為胺基酸，有部分胺基酸人體無法自行合成，必須由飲食中攝取，若是缺乏必需胺基酸，人體會產生缺乏症。常見的豆魚肉蛋類有相當多種，豬肉、雞肉、牛肉、魚肉、蛋等皆是良好的蛋白質來源，若是素食者，則有黃豆製品，如豆腐、豆漿、豆干等皆可供國人選擇。衛生福利部於「每日飲食指南」建議國人每日應攝取三至八份豆魚肉蛋類，每份豆魚肉蛋類依照低、中、高的脂肪含量分別提供55、75、120大卡，低脂份量大小如下圖一。</p>
										<p align="center" ><img src="images/food4.jpg" width="250" height="200" alt=""></p>
				</div>
		</div>
		</div>

	<!-- Copyright -->
		<div id="copyright">
			<div class="container">
							<ul >
								<li><img src="images/PU.PNG" width="120" height="120" alt="">
									<p> </p>
									<p class="posted">April 28, 2019  Comments</p>
								</li>
							</ul>
				Design: <a href="http://www.pu.edu.tw/">靜宜大學資訊工程學系/食品營養學系</a>
			</div>
		</div>
	</body>
</html>