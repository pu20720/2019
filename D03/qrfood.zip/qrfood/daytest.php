<?php
$j = date("t"); //获取当前月份天数
$start_time = strtotime(date('Y-m-01'));  //获取本月第一天时间戳
$array = array();
for($i=0;$i<$j;$i++){
     $array[] = date('Y-m-d',$start_time+$i*86400); //每隔一天赋值给数组
}
?>
print_r($array);