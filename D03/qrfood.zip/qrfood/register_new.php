<?php
include "connect.php";

$http = array(
    100 => "HTTP/1.1 100 Continue",
    101 => "HTTP/1.1 101 Switching Protocols",
    200 => "HTTP/1.1 200 OK",
    201 => "HTTP/1.1 201 Created",
    202 => "HTTP/1.1 202 Accepted",
    203 => "HTTP/1.1 203 Non-Authoritative Information",
    204 => "HTTP/1.1 204 No Content",
    205 => "HTTP/1.1 205 Reset Content",
    206 => "HTTP/1.1 206 Partial Content",
    300 => "HTTP/1.1 300 Multiple Choices",
    301 => "HTTP/1.1 301 Moved Permanently",
    302 => "HTTP/1.1 302 Found",
    303 => "HTTP/1.1 303 See Other",
    304 => "HTTP/1.1 304 Not Modified",
    305 => "HTTP/1.1 305 Use Proxy",
    307 => "HTTP/1.1 307 Temporary Redirect",
    400 => "HTTP/1.1 400 Bad Request",
    401 => "HTTP/1.1 401 Unauthorized",
    402 => "HTTP/1.1 402 Payment Required",
    403 => "HTTP/1.1 403 Forbidden",
    404 => "HTTP/1.1 404 Not Found",
    405 => "HTTP/1.1 405 Method Not Allowed",
    406 => "HTTP/1.1 406 Not Acceptable",
    407 => "HTTP/1.1 407 Proxy Authentication Required",
    408 => "HTTP/1.1 408 Request Time-out",
    409 => "HTTP/1.1 409 Conflict",
    410 => "HTTP/1.1 410 Gone",
    411 => "HTTP/1.1 411 Length Required",
    412 => "HTTP/1.1 412 Precondition Failed",
    413 => "HTTP/1.1 413 Request Entity Too Large",
    414 => "HTTP/1.1 414 Request-URI Too Large",
    415 => "HTTP/1.1 415 Unsupported Media Type",
    416 => "HTTP/1.1 416 Requested range not satisfiable",
    417 => "HTTP/1.1 417 Expectation Failed",
    500 => "HTTP/1.1 500 Internal Server Error",
    501 => "HTTP/1.1 501 Not Implemented",
    502 => "HTTP/1.1 502 Bad Gateway",
    503 => "HTTP/1.1 503 Service Unavailable",
    504 => "HTTP/1.1 504 Gateway Time-out",
);

$response = (Object) array(
    'code' => 0,
    'message' => '',
    'data' => (Object) array(),
);

$account = $_POST['account'];
$password = $_POST['password'];
$name = $_POST['name'];
$gender = $_POST['gender'];
$email = $_POST['email'];
$height = $_POST['height'];
$weight = $_POST['weight'];
$exercise = $_POST['exercise'];


if (!empty($_POST["account"]) && !empty($_POST["password"]) && !empty($_POST["name"])
    && !empty($_POST["gender"]) && !empty($_POST["email"]) && !empty($_POST["height"])
    && !empty($_POST["weight"]) && !empty($_POST["exercise"])) {

    $sql = "SELECT account FROM user WHERE account='" . $account . "'";

    $userInfo = mysqli_query($link, $sql);
    $total_records = mysqli_num_rows($userInfo);

    if ($total_records > 0) {

        $response->code = -1;
        $response->message = 'account repeat';
        header($http[409]);

    } else {
		//將密碼加密儲存到資料庫
		$hash = password_hash($password, PASSWORD_DEFAULT);
		
        $sql = "INSERT INTO `user` (account, password, name, gender, email, height, weight, exercise)";
        $sql = $sql . " VALUES ('$account','$hash','$name','$gender','$email','$height','$weight','$exercise')";
		
        $r = mysqli_query($link, $sql);
		
        $response->code = 1;
        $response->message = 'Success';
        $response->data = $r;
        header($http[200]);
		header("Refresh:0;url=login.php");
    }

    mysqli_close($link);

} else {
    $response->code = -1;
    $response->message = "缺少參數";
    header($http[400]);
	header("Refresh:0;url=login.php");
}

// echo "帳號:".$account."\n密碼:".$password;

header('Content-Type: application/json; charset=utf-8');
//echo json_encode($response, JSON_UNESCAPED_UNICODE);
