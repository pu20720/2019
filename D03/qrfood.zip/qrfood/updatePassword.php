<?php
	include("connect.php");
	
	$password = $_POST['password'];
	$confirmPassword = $_POST['confirmPassword'];
	
	session_start();

if(isset($_COOKIE["uId"])){
	if(isset($_SESSION["uId"]) == $_COOKIE["uId"])
	{
		if($password == $confirmPassword && $password != null)
		{
			$sql = "SELECT * FROM user WHERE uId='";
			$sql.=$_COOKIE["uId"]."'";
			$userInfo = mysqli_query($link, $sql);
			$userInfo = mysqli_fetch_assoc ($userInfo);
			$uId = $_COOKIE['uId'];
			if(password_verify($password,$userInfo['password']))
			{
				echo '新密碼不能和舊密碼相同。';
				header("Refresh:1;url=password.php");
			}
			else 
			{
				//將密碼加密儲存到資料庫
				$hash = password_hash($password, PASSWORD_DEFAULT);
				$sql = "UPDATE `user` SET `password`= '$hash' WHERE uId = $uId";
				$r = mysqli_query($link, $sql);
				if(mysqli_query($link, $sql))
				{
					setcookie('checkPassword','1',time()+3);
					header("Refresh:0;url=user.php");
				}
				else
				{
					setcookie('checkPassword','2',time()+3);
					header("Refresh:0;url=user.php");
				}
			}

				mysqli_close($link);
		}
		else
		{
			print "輸入密碼不一致，請重新輸入。";
			header("Refresh:1;url=password.php");
		}
	}
	else
	{
			echo "尚未登入。";
			header("Refresh:1;url=login.php");
	}
		
}
else
{
	echo "未偵測到COOKIE,請確認COOKIE開啟後再重新登入。";
	header("Refresh:1;url=login.php");
}
?>
	
	