<!DOCTYPE HTML>
<html>
	<head>
		<?php include("head.html");	?>
	</head>
	<body class="homepage">

	<!-- Header -->
		<div id="header">
			<div class="container">
					
				<!-- Logo -->
					<div id="logo">
						<h1><a href="index.php">QRfood</a></h1>
					</div>
				
				<!-- Nav -->
					<nav id="nav">
						<ul>
							<li><a href="index.php">關於本站</a></li>
							<li><a href="foodprofile.php">食物檔案</a></li>
							<li><a href="fooddiary.php">飲食日誌</a></li>
							<li class="active"><a href="information.php">營養資訊</a></li>
							<li><a href="ctrl.php">操作說明</a></li>
							<?php
								session_start();
								if(isset($_COOKIE["uId"])){
									if(isset($_SESSION["uId"]) == $_COOKIE["uId"]){
										if($_COOKIE["role"] == 1){
							?>
											<li><a href="admin.php">管理員介面</a></li>
							<?php		}  ?>
									<li><a href="user.php">使用者資訊</a></li>
									<li><a href="logout.php">登出</a></li>
							<?php
									}
								}else{
							?>
									<li><a href="login.php">登入/註冊</a></li>
							<?php
								}
							?>
						</ul>
					</nav>

			</div>
		</div>
	<!-- Header -->
			
	<!-- Main -->
		<div id="main">
			<div class="container">
				<header>
					<h2>低脂乳品類</h2>
				</header>
				<div class="box">
										
										<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;低脂乳品類為人體蛋白質重要來源之一。蛋白質為構成身體骨骼、牙齒、皮膚、器官、肌肉等身體生長的主要材料，還能調節生理機能，另外，奶類中含有豐富的鈣質，對生長中的孩童及正值發育的青少年相當重要，對於預防骨質疏鬆症亦有效果。衛生福利部於「每日飲食指南」建議國人每日應攝取1.5至2杯低脂乳品。奶類依照脂肪量分為高脂、低脂、脫脂，每杯為240c.c.，熱量分別為150、120、80大卡，下圖一為低脂乳品份量示意圖。需要注意的是有些人喝牛奶後會有腹瀉的現象，可能為乳糖不耐症，表示體內缺乏乳糖酶，導致無法分解牛奶中的乳糖，使得乳糖被腸內細菌代謝產生脹氣，引發腹脹、打嗝、腹痛等症狀，此時可減少食用量，採漸進式的食用牛奶，或者是改喝優酪乳，減少乳糖不耐症之症狀。</p>
										<p align="center" ><img src="images/food5.jpg" width="250" height="200" alt=""></p>
				</div>
		</div>
		</div>


	<!-- Copyright -->
		<div id="copyright">
			<div class="container">
							<ul >
								<li><img src="images/PU.PNG" width="120" height="120" alt="">
									<p> </p>
									<p class="posted">April 28, 2019  Comments</p>
								</li>
							</ul>
				Design: <a href="http://www.pu.edu.tw/">靜宜大學資訊工程學系/食品營養學系</a>
			</div>
		</div>
	</body>
</html>