<!DOCTYPE HTML>
<html>
	<head>
		<?php include("head.html");	?>
	</head>
	<body class="homepage">

		<!-- Header -->
	
	
		<div id="header">
			<div class="container">
					
				<!-- Logo -->
					<div id="logo">
						<h1><a href="index.php">QRfood</a></h1>
					</div>
				
				<!-- Nav -->
					<nav id="nav">
						<ul>
							<li><a href="index.php">關於本站</a></li>
							<li><a href="foodprofile.php">食物檔案</a></li>
							<li class="active"><a href="fooddiary.php">飲食日誌</a></li>
							<li><a href="information.php">營養資訊</a></li>
							<li><a href="ctrl.php">操作說明</a></li>
							<?php
								session_start();
								if(isset($_COOKIE["uId"])){
									if(isset($_SESSION["uId"]) == $_COOKIE["uId"]){
										if($_COOKIE["role"] == 1){
							?>
											<li><a href="admin.php">管理員介面</a></li>
							<?php		}  ?>
									<li><a href="user.php">使用者資訊</a></li>
									<li><a href="logout.php">登出</a></li>
							<?php
									}
								}else{
							?>
									<li><a href="login.php">登入/註冊</a></li>
							<?php
								}
							?>
						</ul>
					</nav>

			</div>
		</div>
	<!-- Header -->
		
	<!-- Main -->
		<div id="main">
			<div class="container">
			<?php 
				if(isset($_COOKIE["uId"]))
				{
			?>
			<header>
				<h2>新增飲食日誌</h2><br>
			</header>
				
				<form name="addnew" method="POST" action="addrecord.php" enctype="multipart/form-data" style="padding-left: 50px;padding-right: 50px;font-size:18px;">
					
					<div>選擇日期：	<input name="date" id="date" type="date" action="addrecord.php">	</div><br>
					
					<div>選擇時段：	<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="time" value="早餐"> 早餐<br>
										&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="time" value="午餐"> 午餐<br>
										&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="time" value="點心"> 點心<br>
										&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="time" value="晚餐"> 晚餐<br>
										&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="time" value="宵夜"> 宵夜<br>
					</div><br>

						
						<div>食物：	<select name="fdId">
		　							<option value="">-----選取-----</option>
									<?php  
										include("connect.php");

										$sql = "SELECT * FROM food WHERE `disable` = '0'";
										$result = mysqli_query($link,$sql);
										
										while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
									?>
									<option value="<?php echo $row['fdId'];?>">	<?php echo $row['fdName'];?>	</option>
									<?php	
										}
										
										$last_id=mysqli_insert_id($link);
									?>
								</select>
						</div><br>
								
						<div>份數：	<select name="serving">
				　								<option value="1">1份</option>
							　					<option value="0.5">0.5份</option>
				　								<option value="1.5">1.5份</option>
				　								<option value="2">2份</option>
											</select>
								
						</div>
					<div>
						<input id="confirm-btn" type="submit" name="submit" value="確定新增" class="button">
					</div>			

				</form>
			<?php
				}
				else
				{
					echo "尚未登入。";
					header("Refresh:1;url=login.php");
				}
			?>
			</div>
		</div>


	<!-- Copyright -->
		<div id="copyright">
			<div class="container">
							<ul >
								<li><img src="images/PU.PNG" width="120" height="120" alt="">
									<p> </p>
									<p class="posted">April 28, 2019  Comments</p>
								</li>
							</ul>
				Design: <a href="http://www.pu.edu.tw/">靜宜大學資訊工程學系/食品營養學系</a>
			</div>
		</div>
	</body>
</html>