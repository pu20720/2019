<!DOCTYPE HTML>
<html>
	<head>
		<?php include("head.html");	?>
	</head>
	<body class="homepage">

	<!-- Header -->
		<div id="header">
			<div class="container">
					
				<!-- Logo -->
					<div id="logo">
						<h1><a href="index.php">QRfood</a></h1>
					</div>
				
				<!-- Nav -->
					<nav id="nav">
						<ul>
							<li><a href="index.php">關於本站</a></li>
							<li><a href="foodprofile.php">食物檔案</a></li>
							<li><a href="fooddiary.php">飲食日誌</a></li>
							<li class="active"><a href="information.php">營養資訊</a></li>
							<li><a href="ctrl.php">操作說明</a></li>
							<?php
								session_start();
								if(isset($_COOKIE["uId"])){
									if(isset($_SESSION["uId"]) == $_COOKIE["uId"]){
										if($_COOKIE["role"] == 1){
							?>
											<li><a href="admin.php">管理員介面</a></li>
							<?php		}  ?>
									<li><a href="user.php">使用者資訊</a></li>
									<li><a href="logout.php">登出</a></li>
							<?php
									}
								}else{
							?>
									<li><a href="login.php">登入/註冊</a></li>
							<?php
								}
							?>
						</ul>
					</nav>

			</div>
		</div>
	<!-- Header -->
			
	<!-- Main -->
		<div id="main">
			<div class="container">
				<header>
					<h2>國民飲食指標</h2>
				</header>
				<div class="box">
										
										<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;「國民飲食指標」，主要是依據我國2005至2008年國民營養健康狀況變遷調查結果，並且參考各個國家之飲食建議進行修訂。舊版「國民飲食指標」為1995年公布，
										至今已二十年有餘，新版的「國民飲食指標」持續宣導均衡飲食、少油、少鹽、少糖、多喝白開水，另外強調了需增加活動量、避免含糖飲料，並且建議國人飲食需減
										少加工、多食用原態食物，並且提醒國人須注意食物產地來源，並且推廣國人進行母乳哺育至少六個月，使嬰孩能夠得到完整的營養來源。</p>
										<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	衛生福利部於2011年修訂了新版的「每日飲食指南」以及「國民飲食指標」，每日飲食指南的目的是提供國人基本的營養建議，針對六大類食
										物應攝取多少份量才能夠滿足大多數國人維持健康的需求，希望能夠透過每日飲食指南的推廣，幫助國人有更正確、更健康的食物選擇。而國民
										飲食指標的目的為建議國人飲食搭配生活型態的方向，除了管控飲食，健康生活型態亦是生活中不可或缺的部分，建議國人在飲食部分以每日飲
										食指南為目標，生活型態能遵循國民飲食指標的內容，以維持健康、預防慢性疾病及改善生活品質。<p>
										國民飲食指標12項原則如下：<br>
										&emsp;&emsp;1.飲食指南作依據，均衡飲食六類足<br>
										&emsp;&emsp;2.健康體重要確保，熱量攝取應控管<br>
										&emsp;&emsp;3.維持健康多活動，每日至少三十分<br>
										&emsp;&emsp;4.母乳營養價值高，哺餵至少六個月<br>
										&emsp;&emsp;5.全榖根莖當主食，營養升級質更優<br>
										&emsp;&emsp;6.太鹹不吃少醃漬，低脂少炸少沾醬<br>
										&emsp;&emsp;7.含糖飲料應避免，多喝開水更健康<br>
										&emsp;&emsp;8.少葷多素少精緻，新鮮粗食少加工<br>
										&emsp;&emsp;9.購食點餐不過量，分量適中不浪費<br>
										&emsp;&emsp;10.當地在地好食材，多樣選食保健康<br>
										&emsp;&emsp;11.來源標示要注意，衛生安全才能吃<br>
										&emsp;&emsp;12.若要飲酒不過量，懷孕絕對不喝酒<br><br>
										&emsp;&emsp;<img src="images/averagepoint.jpg" width="50%" height="50%" alt="">
										
				</div>
		</div>
		</div>

	<!-- Copyright -->
		<div id="copyright">
			<div class="container">
							<ul >
								<li><img src="images/PU.PNG" width="120" height="120" alt="">
									<p> </p>
									<p class="posted">April 28, 2019  Comments</p>
								</li>
							</ul>
				Design: <a href="http://www.pu.edu.tw/">靜宜大學資訊工程學系/食品營養學系</a>
			</div>
		</div>
	</body>
</html>