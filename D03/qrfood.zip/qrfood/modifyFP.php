<!DOCTYPE HTML>
<html>
	<head>
		<?php include("head.html");	?>
	</head>
	<style>
				body {
			font-family:Microsoft JhengHei;
		}

		.content .loginForm .line input[type='text'],
		.content .loginForm .line input[type='password'],
		.content .loginForm .line select {
			display: block;
			margin: 0 auto;
			width: 320px;
			margin-top: 12px;
			padding: 12px 15px;
			border: 1px solid #dad8d3;
			border-radius: 3px;
			line-height: 14px;
			font-size: 12px;
			background-color: #ffffff;
			margin-left: 16px;
		}

		.content {
			width: 100%;
			min-height: 450px;
			padding-bottom: 100px;
			background-color: #ffffff;
		}

		.content .title {
			margin: 0px 0 50px;
			text-align: center;
			font-size: 30px;
			font-weight: 700;
		}

		.btn {
			display: block;
			width: 320px;
			height: 36px;
			margin-left: 16px;
			margin-top: 30px;
			border: none;
			border-radius: 3px;
			border:3px double;
			text-align: center;
			vertical-align: middle;
			color: #ffffff;
			font-size: 13px;
			background-color: #1b1a1a;
			cursor: pointer;
		}

		.content .loginForm .btnLine .btn {
			width: 100%;
		}

		.content .loginForm {
			width: 360px;
			margin: 0 auto;
		}
		
		.divider {
			text-align: center;
			white-space: nowrap;
			margin-top: 10px;
			margin-bottom: 10px;
		}
	</style>

		<div id="header">
			<div class="container">
					
				<!-- Logo -->
					<div id="logo">
						<h1><a href="index.php">QRfood</a></h1>
					</div>
				
				<!-- Nav -->
					<nav id="nav">
						<ul>
							<li><a href="index.php">關於本站</a></li>
							<li><a href="foodprofile.php">食物檔案</a></li>
							<li><a href="fooddiary.php">飲食日誌</a></li>
							<li><a href="information.php">營養資訊</a></li>
							<li><a href="ctrl.php">操作說明</a></li>
							<?php
								session_start();
								if(isset($_COOKIE["uId"])){
									if(isset($_SESSION["uId"]) == $_COOKIE["uId"]){
										if($_COOKIE["role"] == 1){
							?>
											<li class="active"><a href="admin.php">管理員介面</a></li>
							<?php		}  ?>
									<li><a href="user.php">使用者資訊</a></li>
									<li><a href="logout.php">登出</a></li>
							<?php
									}
								}else{
							?>
									<li><a href="login.php">登入/註冊</a></li>
							<?php
								}
							?>
						</ul>
					</nav>

			</div>
		</div>

		<div id="main">
			<header>
				<center>
					<h2>修改食物檔案</h2>
				</center>
			</header>
		</div>
		
	<body>
		<div class="content">
				<?php
					$fdId = $_GET["id"];
					
					include('connect.php');
					$sql = "SELECT *  FROM `food` WHERE `fdId` = '$fdId' ";
					$result = mysqli_query($link,$sql);
					$row = mysqli_fetch_assoc($result);
					setcookie("fdId",$row['fdId'],time() + 600);
					$no="查無資料";
					$a="";
					$a2="";
					$b="";
					
					$sql2 = "SELECT * FROM `restaurant`";
					$result2 = mysqli_query($link,$sql2);
					
					$sql3 = "SELECT * FROM `restaurant`";
					$result3 = mysqli_query($link,$sql3);
					
					$sql4 = "SELECT * FROM `category`";
					$result4 = mysqli_query($link,$sql4);
						
					$sql5 = "SELECT * FROM `category`";
					$result5 = mysqli_query($link,$sql5);
				?>
				
				
			<form class="loginForm" name="modifyFP" method="POST" action="adminUpdate.php" enctype="multipart/form-data">
				<div class="line">
					<div class="align">餐廳:</div>
					<select class="select" id="rsId" name="rsId">
						<?php
							while($row2=$result2->fetch_assoc()){
								if($row['rsId'] == $row2['rsId']){
									$a=$row2['location'];
									$a2=$row2['rsName'];
								}
							}
						?>
							<option value="<?php echo $row["rsId"];?>"><?php if($row!=null){echo $a,$a2; }	else{echo $no;}?></option>
						
						<?php
							while($row3=$result3->fetch_assoc()){?>
								<option value="<?php echo $row3["rsId"]?>"><?php echo $row3['location'],$row3['rsName']?></option>
						<?php	}?>
						
					</select>
				</div>

				<div class="line">
					<div class="align">食物名稱:</div>
					<input type="text" name="fdName" maxlength="10"  value="<?php if($row!=null){echo $row["fdName"];}	else{echo $no;}?>"	required>
				</div>
				
				<div class="line">
					<div class="align">食物種類:</div>
					<select class="select" id="cId" name="cId">
						
						<?php
							while($row4=$result4->fetch_assoc()){
								if($row['cId'] == $row4['cId']){
									$b=$row4['cName'];
								}
							}
						?>
								<option value="<?php echo $row["cId"];?>"><?php if($row!=null){echo $b;}	else{echo $no;} ?></option>
						
						<?php	while($row5=$result5->fetch_assoc()){?>
									<option value="<?php echo $row5["cId"]?>"><?php echo $row5['cName']?></option>
						<?php	}?>
						
					</select>
				</div>
				
				<div class="line">
					<div class="align">克數:</div>
					<input type="text" name="gram" value="<?php if($row!=null){echo $row["gram"];}	else{echo $no;}?>"	required>
				</div>
				
				<div class="line">
					<div class="align">卡路里:</div>
					<input type="text" name="calorie" value="<?php if($row!=null){echo $row["calorie"];}	else{echo $no;}?>" required>
				</div>
				
				<div class="line">
					<div class="align">蛋白質:</div>
					<input type="text" name="protein" value="<?php if($row!=null){echo $row["protein"];}	else{echo $no;}?>" required>
				</div>
				
				<div class="line">
					<div class="align">脂肪(總):</div>
					<input type="text" name="fat" value="<?php if($row!=null){echo $row["fat"];}	else{echo $no;}?>" required>
				</div>
				
				<div class="line">
					<div class="align">飽和脂肪:</div>
					<input type="text" name="saturatedfat" value="<?php if($row!=null){echo $row["saturatedFat"];}	else{echo $no;}?>" required>
				</div>
				
				<div class="line">
					<div class="align">反式脂肪:</div>
					<input type="text" name="transfat" value="<?php if($row!=null){echo $row["transFat"];}	else{echo $no;}?>" required>
				</div>
				
				<div class="line">
					<div class="align">膽固醇(毫克):</div>
					<input type="text" name="cholesterol" value="<?php if($row!=null){echo $row["cholesterol"];}	else{echo $no;}?>" required>
				</div>
				
				<div class="line">
					<div class="align">碳水化合物(總):</div>
					<input type="text" name="carbohydrate" value="<?php if($row!=null){echo $row["carbohydrate"];}	else{echo $no;}?>" required>
				</div>
				
				<div class="line">
					<div class="align">糖:</div>
					<input type="text" name="sugar" value="<?php if($row!=null){echo $row["sugar"];}	else{echo $no;}?>" required>
				</div>
				
				<div class="line">
					<div class="align">膳食纖維:</div>
					<input type="text" name="dietaryFiber" value="<?php if($row!=null){echo $row["dietaryFiber"];}	else{echo $no;}?>" required>
				</div>
				
				<div class="line">
					<div class="align">納(毫克):</div>
					<input type="text" name="sodium" value="<?php if($row!=null){echo $row["sodium"];}	else{echo $no;}?>" required>
				</div>
				
				<div class="line">
					<div class="align">鈣(毫克):</div>
					<input type="text" name="calcium" value="<?php if($row!=null){echo $row["calcium"];}	else{echo $no;}?>" required>
				</div>
				
				<div class="line">
					<div class="align">鉀(毫克):</div>
					<input type="text" name="potassium" value="<?php if($row!=null){echo $row["potassium"];}	else{echo $no;}?>" required>
				</div>
				
				<div class="line">
					<div class="align">鐵(毫克):</div>
					<input type="text" name="ferrum" value="<?php if($row!=null){echo $row["ferrum"];}	else{echo $no;}?>" required>
				</div>
				
				<div class="line">
					<div class="align">資料是否顯示給使用者:</div>
					<select class="select" name="disable">
						<option value="<?php echo $row["disable"];?>"><?php if($row!=null){if($row["disable"] == 0){echo "顯示";} else if($row["disable"] == 1){echo "不顯示";} }	else{echo $no;}?></option>
						<option value="0">顯示</option>
						<option value="1">不顯示</option>
					</select>
				</div>
				
				<label>圖片：<input type="file" name="file" value="<?php if($row!=null){echo $row["photo"];}	else{echo $no;}?>"}></label>
				
				<div>
					<input id="confirm-btn" type="submit" name="submit" value="送出" class="btn">
				</div>
				
			</form>
		</div>

				

	<!-- Copyright -->
		<div id="copyright">
			<div class="container">
							<ul >
								<li><img src="images/PU.PNG" width="120" height="120" alt="">
									<p> </p>
									<p class="posted">April 28, 2019  Comments</p>
								</li>
							</ul>
				Design: <a href="http://www.pu.edu.tw/">靜宜大學資訊工程學系/食品營養學系</a>
			</div>
		</div>
	</body>
</html>