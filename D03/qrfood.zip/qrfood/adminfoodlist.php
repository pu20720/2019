<!DOCTYPE HTML>
<html>
	<head>
		<?php include("head.html");	?>
	</head>
	<body class="homepage">

	<!-- Header -->
		<div id="header">
			<div class="container">
					
				<!-- Logo -->
					<div id="logo">
						<h1><a href="index.php">QRfood</a></h1>
					</div>
				
				<!-- Nav -->
					<nav id="nav">
						<ul>
							<li><a href="index.php">關於本站</a></li>
							<li><a href="foodprofile.php">食物檔案</a></li>
							<li><a href="fooddiary.php">飲食日誌</a></li>
							<li><a href="information.php">營養資訊</a></li>
							<li><a href="ctrl.php">操作說明</a></li>
							<?php
								session_start();
								if(isset($_COOKIE["uId"])){
									if(isset($_SESSION["uId"]) == $_COOKIE["uId"]){
										if($_COOKIE["role"] == 1){
							?>
											<li class="active"><a href="admin.php">管理員介面</a></li>
							<?php		}  ?>
									<li><a href="user.php">使用者資訊</a></li>
									<li><a href="logout.php">登出</a></li>
							<?php
									}
								}else{
							?>
									<li><a href="login.php">登入/註冊</a></li>
							<?php
								}
							?>
						</ul>
					</nav>

			</div>
		</div>
	<!-- Header -->
		
	<!-- Main -->
	<?php if(isset($_COOKIE["role"]) == 1){?>
		<div id="main">
			<div class="container">
				
				<header>
					<h2><?php echo $_POST['rest'];?>餐廳</h2>
					<div class="row">
						<div class="col+">
							<a href="AddNewFP.php" class="button">新增食物</a>
							<a href="AddNewRT.php" class="button">新增餐廳</a>
						</div>
					</div>
				</header>
				<div>
				<input id="search" type="text" placeholder="輸入要搜尋內容..."/>
				<span id="search-btn" style="cursor: pointer">搜尋</span>
				</div>
				<div id="content">
				<?php
					include('connect.php');
					$rest = $_POST['rest'];
					$sql = "SELECT *  FROM `restaurant` WHERE `location` = '$rest' ";
					$r = mysqli_query($link,$sql);
					while($row=$r->fetch_assoc()){
						$a = $row["rsId"];
						$sql2 = "SELECT *  FROM `food` WHERE `rsId` = '$a' ";
						$result = mysqli_query($link,$sql2);
					
					$n=1;
                ?>
				
				
			
			<table class="table table-sm" style="text-align:center;">
			<div id="content">
				<strong><p style="font-size:25px"><?php echo $row['rsName']; ?></p></strong>
			</div>
			  <thead>
				<tr>
				  <th scope="col">NO.</th>
				  <th scope="col">食物名稱</th>
				  <th scope="col">單位</th>
				  <th scope="col">份量</th>
				  <th scope="col">一般使用者是否可見</th>
				  <th scope="col">修改資料</th>
				  <th scope="col">刪除資料</th>
				</tr>
			  </thead>
			  <tbody>
				<?php	while($row=$result->fetch_assoc()){?>
				<tr>
				  <th scope="row"><?php echo $n?></th>
				  <td><?php echo $row["fdName"] ?></td>
				  <td>1份</td>
				  <td><?php echo $row["gram"]	?>g</td>
				  <td><?php if($row["disable"]==0){echo "是";}	else{echo "否";}?></td>
				  <td><?php echo "<a href=\"modifyFP.php?id=".$row["fdId"]."\">修改食物</a>";	?></td>
				  <td><?php echo "<a href=\"checkDFP.php?id=".$row["fdId"]."\">刪除食物</a>";	?></td>
				</tr>
					<?php	$n++; }}?>
			
			  </tbody>
			  
			</table>
				</div>
			</div>
		</div>
<script>
    var content = $('#content').html();
    $('#search-btn').click(function () {
        $('#content').html(content);
        var searchText = $('#search').val();
        if (searchText.length == 0) {
            return false;
        }
        var regExp = new RegExp(searchText, 'g');
        var newHtml = content.replace(regExp, '<span id="result" style="background:yellow;color:red;">' + searchText + '</span>');
        $('#content').html(newHtml);
        var X = $('#result').offset().top;
        var Y = $('#result').offset().left;
        window.scrollTo(X, Y);
    });
</script>
	<?php 
	}else
	{	echo "非管理員禁止進入。";}
	
	?>
	<!-- Copyright -->
		<div id="copyright">
			<div class="container">
							<ul >
								<li><img src="images/PU.PNG" width="120" height="120" alt="">
									<p> </p>
									<p class="posted">April 28, 2019  Comments</p>
								</li>
							</ul>
				Design: <a href="http://www.pu.edu.tw/">靜宜大學資訊工程學系/食品營養學系</a>
			</div>
		</div>
	</body>
</html>

