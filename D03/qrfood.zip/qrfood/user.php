<!DOCTYPE HTML>
<html>
	<head>
		<?php include("head.html");	?>
	</head>
	<body class="homepage">

	<!-- Header -->
		<div id="header">
				<!-- Logo -->
					<div id="logo">
						<h1><a href="index.php">QRfood</a></h1>
					</div>
				
				<!-- Nav -->
					<nav id="nav">
						<ul>
							<li><a href="index.php">關於本站</a></li>
							<li><a href="foodprofile.php">食物檔案</a></li>
							<li><a href="fooddiary.php">飲食日誌</a></li>
							<li><a href="information.php">營養資訊</a></li>
							<li><a href="ctrl.php">操作說明</a></li>
							<?php
								session_start();
								if(isset($_COOKIE["uId"])){
									if(isset($_SESSION["uId"]) == $_COOKIE["uId"]){
										if($_COOKIE["role"] == 1){
							?>
											<li><a href="admin.php">管理員介面</a></li>
							<?php		}  ?>
									<li class="active"><a href="user.php">使用者資訊</a></li>
									<li><a href="logout.php">登出</a></li>
							<?php
									}
								}else{
							?>
									<li><a href="login.php">登入/註冊</a></li>
							<?php
								}
							?>
						</ul>
					</nav>

			</div>

	<!-- Header -->
			
	<!-- Main -->
		<div id="main">
			<div class="container">

								
<header>
	<h2>使用者資訊</h2>
</header>	
	<?php	if(isset($_COOKIE['check']) == '1')
			{
	?>
	<font color="green">	<?php echo "修改成功!"; ?>  </font>
	<?php	}
			else if(isset($_COOKIE['check']) == '2')
			{
	?>
	<font color="red">	<?php echo "資料更新失敗。"; ?>	</font>
	<?php
			}
			
			if(isset($_COOKIE['checkPassword']) == '1')
			{
	?>
	<font color="green"><?php	echo "密碼更改成功!";	?>	</font>
	<?php	}
			else if(isset($_COOKIE['checkPassword']) == '2')
			{
	?>
	<font color="red">	<?php	echo "資料庫更新失敗。";	?>	</font>
	<?php	
			}
	?>

				<?php
					if(isset($_COOKIE["uId"])){
						if($_SESSION["uId"] == $_COOKIE["uId"]){
							
						$link = @mysqli_connect("localhost","root411","root411root41","qrfood");
						mysqli_query( $link, "SET NAMES 'utf8'");
						$sql = "SELECT * FROM user WHERE uId='";
						
						$sql.=$_COOKIE["uId"]."'";
						$userInfo = mysqli_query($link, $sql);
						$total_records = mysqli_num_rows($userInfo);

						if( $total_records > 0 ) {
							$userInfo = mysqli_fetch_assoc ($userInfo);
							
							if($userInfo["gender"] == 1)
							{
								$userInfo["gender"] = "男";
							}
							else
							{
								$userInfo["gender"] = "女";
							}
						}
				?>
				<table class="table" >
				  <tbody>
					<tr>
					  <th scope="row">姓名:</th>
						<td> 
							<?php
								echo $userInfo["name"]
							?> 
						</td>
					</tr>
					<tr>
					  <th scope="row">生理性別:</th>
						<td> 
							<?php
								echo $userInfo["gender"]
							?> 
						</td>
					</tr>
					<tr>
					  <th scope="row">身高:</th>
						<td> 
							<?php
								echo $userInfo["height"]
							?> 
						</td>
					</tr>
					<tr>
					  <th scope="row">體重:</th>
						<td> 
							<?php
								echo $userInfo["weight"]
							?> 
						</td>
					</tr>
					<tr>
					  <th scope="row">運動量:</th>
						<td> 
							<?php
								echo $userInfo["exercise"]
							?> 
						</td>
					</tr>
					<tr>
					  <th scope="row">信箱:</th>
						<td> 
							<?php
								echo $userInfo["email"]
							?> 
						</td>
					</tr>
				</tbody>
			</table>
	
				<?php

					mysqli_close($link);
						
						}else{
							echo "尚未登入。";
							header("Refresh:1;url=login.html");
						}
						
					}else{
						echo "未偵測到COOKIE,請確認COOKIE開啟後再重新執行。";
						header("Refresh:1;url=index.php");
					}
				?>
				
				<a href="updateUser.php" class="button">修改個人資料</a>
				<a href="confirmPassword.php" class="button">更改密碼</a>
					

		</div>
		</div>
	
	<!-- Copyright -->
		<div id="copyright">
			<div class="container">
							<ul >
								<li><img src="images/PU.PNG" width="120" height="120" alt="">
									<p> </p>
									<p class="posted">April 28, 2019  Comments</p>
								</li>
							</ul>
				Design: <a href="http://www.pu.edu.tw/">靜宜大學資訊工程學系/食品營養學系</a>
			</div>
		</div>
	</body>
</html>