<?php
include("connect.php");

$date = $_POST['date'];
$time = $_POST['time'];
$fdId = $_POST['fdId'];
$serving = $_POST['serving'];


if (isset($_COOKIE["uId"])) {
	$uId = $_COOKIE['uId'];
    session_start();
    if (isset($_SESSION["uId"]) == $_COOKIE["uId"]) {
        //新增一筆飲食紀錄
        $sql = "INSERT INTO record (uId,date,time,fdId,serving) VALUES ("
            . "'" . $uId . "',"
            . "'" . $date . "',"
            . "'" . $time . "',"
            . "'" . $fdId . "',"
            . "'" . $serving . "')";
		$addrecord = mysqli_query($link, $sql);
		
		if($addrecord)
		{
			$sql2 = "select * from food where fdId = '$fdId'";
			$userInfo = mysqli_query($link, $sql2);
			$row = mysqli_fetch_assoc ($userInfo);
			
			$calorie		= $row['calorie']*$serving;
			$protein		= $row['protein']*$serving;
			$fat			= $row['fat']*$serving;
			$saturatedFat	= $row['saturatedFat']*$serving;
			$transFat		= $row['transFat']*$serving;
			$cholesterol	= $row['cholesterol']*$serving;
			$carbohydrate	= $row['carbohydrate']*$serving;
			$sugar			= $row['sugar']*$serving;
			$dietaryFiber	= $row['dietaryFiber']*$serving;
			$sodium			= $row['sodium']*$serving;
			$calcium		= $row['calcium']*$serving;
			$potassium		= $row['potassium']*$serving;
			$ferrum			= $row['ferrum']*$serving;
			
			$sql3 = "INSERT INTO dailyrecord (uId,date,calorie,protein,fat,saturatedFat,transFat,
			cholesterol,carbohydrate,sugar,dietaryFiber,sodium,calcium,potassium,ferrum) VALUES ("
            . "'" . $uId . 			"',"
            . "'" . $date . 		"',"
            . "'" . $calorie .		"',"
            . "'" . $protein . 		"',"
			. "'" . $fat . 			"',"
			. "'" . $saturatedFat . "',"
			. "'" . $transFat . 	"',"
			. "'" . $cholesterol .	"',"
			. "'" . $carbohydrate . "',"
			. "'" . $sugar . 		"',"
			. "'" . $dietaryFiber . "',"
			. "'" . $sodium . 		"',"
			. "'" . $calcium . 		"',"
			. "'" . $potassium . 	"',"
			. "'" . $ferrum . 		"')";
			$dailyrecord = mysqli_query($link, $sql3);
			if($dailyrecord)
			{
				/*print "新增食物成功，跳轉至飲食日誌。";*/
				header("Refresh:0;url=fooddiary.php");
			}
			else
			{
				/*print "新增食物失敗，請重新執行。";*/
				header("Refresh:0;url=addnew.php");
			}
		}
		else
		{
			/*print "新增食物失敗，請重新執行。";*/
			header("Refresh:0;url=addnew.php");
		}
		mysqli_close($link);
    } else {
        echo "尚未登入。";
		header("Refresh:1;url=login.php");
    }
} else {
    echo "未偵測到COOKIE,請確認COOKIE開啟後再重新登入。";
	header("Refresh:1;url=login.php");
}
?>