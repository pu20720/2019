<!DOCTYPE HTML>
<html>
	<head>
		<?php include("head.html");	?>
	</head>
	<body class="homepage">

	<!-- Header -->
		<div id="header">
			<div class="container">
					
				<!-- Logo -->
					<div id="logo">
						<h1><a href="index.php">QRfood</a></h1>
					</div>
				
				<!-- Nav -->
					<nav id="nav">
						<ul>
							<li><a href="index.php">關於本站</a></li>
							<li><a href="foodprofile.php">食物檔案</a></li>
							<li><a href="fooddiary.php">飲食日誌</a></li>
							<li class="active"><a href="information.php">營養資訊</a></li>
							<li><a href="ctrl.php">操作說明</a></li>
							<?php
								session_start();
								if(isset($_COOKIE["uId"])){
									if(isset($_SESSION["uId"]) == $_COOKIE["uId"]){
										if($_COOKIE["role"] == 1){
							?>
											<li><a href="admin.php">管理員介面</a></li>
							<?php		}  ?>
									<li><a href="user.php">使用者資訊</a></li>
									<li><a href="logout.php">登出</a></li>
							<?php
									}
								}else{
							?>
									<li><a href="login.php">登入/註冊</a></li>
							<?php
								}
							?>
						</ul>
					</nav>

			</div>
		</div>
	<!-- Header -->
			
	<!-- Main -->
		<div id="main">
			<div class="container">
				<header>
					<h2>水果類</h2>
				</header>
				<div class="box">
										
										<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;水果類富含維生素及膳食纖維。其中維生素C含量甚為突出，能夠增加抵抗力、預防感冒。常見的水果有木瓜、草莓、蘋果、芭樂及鳳梨等。台灣一直被稱為水果王國，顧名思義在我國有豐富的水果資源，一年四季皆能攝取到不同的水果。無論何種水果，在營養素的計算上，一份水果皆為60大卡，份量大小如下圖一，而依照水果的種類，則有不同的克數，如下表一所示，表格內主要為衛生福利部所提供之食物代換表，不足部分以衛福部食品營養成分查詢進行補強。衛生福利部於「每日飲食指南」建議國人每日應攝取二至四份水果。需要注意的是水果類內含醣類較高，任何人攝食水果，切記不可攝取過量，以免導致體內血糖過高。</p>
										<p align="center" ><img src="images/food3.jpg" width="250" height="200" alt=""></p>
				</div>
		</div>
		</div>


	<!-- Copyright -->
		<div id="copyright">
			<div class="container">
							<ul >
								<li><img src="images/PU.PNG" width="120" height="120" alt="">
									<p> </p>
									<p class="posted">April 28, 2019  Comments</p>
								</li>
							</ul>
				Design: <a href="http://www.pu.edu.tw/">靜宜大學資訊工程學系/食品營養學系</a>
			</div>
		</div>
	</body>
</html>